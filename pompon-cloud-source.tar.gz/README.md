# Pompón Cloud: prueba en Render

El usuario autorizó probar Render Free en Virginia. render.yaml contiene la configuración: Node 22, build con cloud-multiplayer/build.cjs, inicio con cloud-multiplayer/start.cjs y salud /api/version.

POMPON_SERVER_TYPE=cloud
POMPON_REGION=virginia
POMPON_MAX_ROOMS=10
PORT es proporcionado por Render. No se requieren claves privadas para este backend.

Las salas públicas y privadas se mantienen en el servidor cloud y continúan cuando sale su creador mientras quedan jugadores. El estado está en memoria: se pierde si Render reinicia el proceso. Render Free suspende el servicio tras 15 minutos sin tráfico; no es una entrega de producción ni garantiza baja latencia.

Hostear desde mi PC conserva Node y Cloudflare Tunnel, de manera independiente.

Después de desplegar: verificar /api/version, crear sala con dos clientes, comprobar sincronización y salida del creador, y configurar la URL HTTPS real en Pompón. No hay URL de despliegue confirmada todavía.

Los archivos deploy/oci y deploy/gcp se conservan como alternativas anteriores; no se van a desplegar en esta prueba.
