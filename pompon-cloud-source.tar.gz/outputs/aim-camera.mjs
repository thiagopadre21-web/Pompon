import * as T from './vendor/three.module.js';
export const MATCH_FOV=55, MATCH_SIGHT_Y=.16;
export const DEFAULT_CAMERA_DISTANCE=5.3, DEFAULT_CAMERA_PITCH=.08;
export function cameraOffset(yaw,pitch){return new T.Vector3(Math.sin(yaw)*Math.cos(pitch),Math.sin(pitch),Math.cos(yaw)*Math.cos(pitch));}
export function sightPixels(width,height){return {x:width*.5,y:height*.42};}
export function practiceCamera(camera,p,yaw,pitch,distance){
 const offset=cameraOffset(yaw,pitch),focus=new T.Vector3(p.x,p.y+1.35,p.z);
 // Keep the lens above the practice floor without limiting upward aim.
 // A minimum horizontal clearance also keeps steep views outside the avatar.
 const horizontal=Math.max(1.5,Math.cos(pitch)*distance);
 camera.position.set(focus.x+Math.sin(yaw)*horizontal,Math.max(.25,focus.y+offset.y*distance),focus.z+Math.cos(yaw)*horizontal);
 camera.lookAt(camera.position.clone().addScaledVector(offset,-10));camera.fov=MATCH_FOV;camera.updateProjectionMatrix();camera.updateMatrixWorld(true);
}

