export const arenaSpawns={a:[{x:-20,y:0,z:-4,heading:Math.PI/2},{x:-20,y:0,z:4,heading:Math.PI/2}],b:[{x:20,y:0,z:4,heading:-Math.PI/2},{x:20,y:0,z:-4,heading:-Math.PI/2}]};
export function spawnFor(arena,id){const team=arena.teams[id]||'a',ids=Object.keys(arena.teams).filter(id=>arena.teams[id]===team);return arenaSpawns[team][Math.max(0,ids.indexOf(id))%2];}
export function makeArena(mode='1v1'){return {mode,teams:{},wins:{a:0,b:0},phase:'lobby',round:0,nextRound:0,winner:null};}
export function canStart(arena,ids){const size=arena.mode==='2v2'?2:1;return ids.length===size*2&&['a','b'].every(t=>ids.filter(id=>arena.teams[id]===t).length===size);}
export function scoreRound(arena,players,now){if(arena.phase!=='playing')return false;const alive=t=>players.some(p=>arena.teams[p.id]===t&&p.health>0);const a=alive('a'),b=alive('b');if(a&&b)return false;arena.winner=a?'a':b?'b':null;if(arena.winner)arena.wins[arena.winner]++;arena.phase='roundover';arena.nextRound=now+4000;return true;}
const originalBlocks=[{x:0,z:-16,w:40,d:1,h:4},{x:0,z:16,w:40,d:1,h:4},{x:-20,z:0,w:1,d:32,h:4},{x:20,z:0,w:1,d:32,h:4},
 ...[-1,1].flatMap(side=>[{x:side*10,z:-6,w:3,d:2,h:1.2},{x:side*10,z:6,w:3,d:2,h:1.2},{x:side*5,z:0,w:1,d:5,h:.65},{x:side*5,z:0,w:1,d:5,h:3.4,yMin:2},{x:side*5,z:-3,w:1,d:1,h:3.4},{x:side*5,z:3,w:1,d:1,h:3.4},{x:side*2,z:9,w:4,d:5,h:2.4,yMin:2.15},{x:side*6,z:9,w:2,d:7,h:2.4,baseY:0,ramp:true},{x:side*2,z:11.5,w:4,d:.4,h:3.1,yMin:2.4}]),{x:0,z:-7,w:4,d:3,h:1.4},{x:0,z:1,w:2,d:2,h:.8}];

// Wider lanes and mirrored cover keep both teams equally protected.
export const arenaBlocks=originalBlocks.map(b=>({...b,x:b.x*1.3,z:b.z*1.3,w:b.w*1.3,d:b.d*1.3})).concat(...[-1,1].map(side=>[
 {x:side*17,z:-9,w:2,d:5,h:2.7},{x:side*17,z:9,w:2,d:5,h:2.7},
 {x:side*8,z:-15,w:4,d:1.2,h:2.3},{x:side*11,z:15,w:2.5,d:2.5,h:1.3}
]));
export function arenaUtility(a){if(a.utilityRound!==a.round){a.utilityRound=a.round;a.utility={projectiles:[],effects:[]};a.utilityUsed={};}return a.utility;}
