export const upgradeKinds=['stamina','recovery','vision'];
export function progression(value={}){return {gold:Math.max(0,Math.floor(Number(value.gold)||0)),total:Math.max(0,Math.floor(Number(value.total)||0)),levels:Object.fromEntries(upgradeKinds.map(k=>[k,Math.max(0,Math.min(10,Math.floor(Number(value.levels?.[k])||0)))])),fov:Math.max(55,Math.min(85,Number(value.fov)||55))};}
export function upgradeCost(level){return 20*(level+1);}
export function buyUpgrade(p,kind,infiniteGold=false){if(!upgradeKinds.includes(kind))return {error:'Mejora inválida'};p.economy=progression(p.economy);const e=p.economy,level=e.levels[kind],cost=upgradeCost(level);if(level>=10)return {error:'Nivel máximo: 10'};if(!infiniteGold&&e.gold<cost)return {error:'No tenés suficiente oro'};if(!infiniteGold)e.gold-=cost;e.levels[kind]++;return {ok:true,economy:e};}
export function rewardKill(killer,victim){if(!killer||!victim||killer.id===victim.id)return;const e=killer.economy=progression(killer.economy);const reward=killer.clan&&victim.clan&&killer.clan!==victim.clan?25:20;e.gold+=reward;e.total+=reward;resetOnDeath(victim);return reward;}
export function resetOnDeath(player){const e=player.economy=progression(player.economy);e.gold=0;e.total=0;e.levels={stamina:0,recovery:0,vision:0};e.fov=55;}

