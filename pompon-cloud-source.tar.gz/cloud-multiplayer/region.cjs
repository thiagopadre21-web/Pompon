const REGION='southamerica-east1';
function checkRegion(region){if(![REGION,'sa-saopaulo-1','virginia'].includes(region))throw Error('Región cloud no autorizada. Usar São Paulo o Virginia para la prueba Render.');return region;}
module.exports={REGION,checkRegion};
