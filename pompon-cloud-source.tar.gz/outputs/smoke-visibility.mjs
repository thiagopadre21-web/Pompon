import {smokeBlocks} from './utility-rules.mjs';
let effects=[];
export function setSmokeEffects(value){effects=value||[];}
export function clearThroughSmoke(camera,point){return !smokeBlocks(effects,camera.position,point);}
