import {recipes} from './crafting.mjs';
export function chestAction(room,player,a,now=Date.now()){
 const b=room.buildings.get(a.uid);if(!b||b.id!=='chest'||b.hp<=0)return {error:'El cofre ya no existe'};
 if(Math.hypot(b.x-player.pose.x,b.z-player.pose.z)>3.5||Math.abs((b.baseY||0)-player.pose.y)>3)return {error:'Acercate al cofre'};
 b.contents??=Array(10).fill(null);room.chestReceipts??=new Map();const key=player.id+':'+a.operation;if(a.operation&&room.chestReceipts.has(key))return room.chestReceipts.get(key);
 let result={contents:b.contents};if(a.action==='put'){
 const item=room.items.get(a.item),index=b.contents.findIndex(v=>!v);if(index<0)return {error:'El cofre está lleno'};if(!item||item.owner!==player.id)return {error:'Ese objeto ya no está en tu inventario'};
 b.contents[index]=structuredClone(item);room.items.delete(item.id);(room.retiredItems??=new Set()).add(item.id);result={contents:b.contents,removed:item.id};
 }else if(a.action==='take'){
 if(!Number.isInteger(a.slot)||a.slot<0||a.slot>=10||!b.contents[a.slot])return {error:'Ese espacio está vacío'};
 if(![0,1,2,5,6,7,8,9,10,11,12,13,14].includes(a.cell)||[...room.items.values()].some(i=>i.owner===player.id&&i.cell===a.cell))return {error:'Necesitás una casilla vacía'};
 const item={...b.contents[a.slot],id:a.newId,owner:player.id,cell:a.cell,state:'stored'};if(typeof item.id!=='string'||item.id.length>100||room.items.has(item.id)||room.retiredItems?.has(item.id))return {error:'Reintentá retirar el objeto'};
 room.items.set(item.id,item);b.contents[a.slot]=null;result={contents:b.contents,received:item};
 }else if(a.action!=='view')return {error:'Acción inválida'};
 b.openUntil=now+2000;if(a.operation){room.chestReceipts.set(key,structuredClone(result));if(room.chestReceipts.size>200)room.chestReceipts.delete(room.chestReceipts.keys().next().value);}return result;
}
export function spillChest(room,b){for(const [index,item]of (b.contents||[]).entries())if(item){const id='spill-'+b.uid+'-'+index;room.items.set(id,{...item,id,owner:null,cell:-1,state:'world',a:[b.x+Math.sin(index)*.4,(b.baseY||0)+.2,b.z+Math.cos(index)*.4],b:[b.x+.3,(b.baseY||0)+.2,b.z]});}b.contents=[];}
