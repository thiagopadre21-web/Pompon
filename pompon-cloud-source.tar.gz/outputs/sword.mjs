import * as T from './vendor/three.module.js';
import {makeSwordBody,stepSword,SWORD_LENGTH} from './sword-physics.mjs';
export function createSword(scene,blocks,carrier){
 const root=new T.Group();scene.add(root);
 const steel=new T.MeshStandardMaterial({color:0xb4c8d6,metalness:.72,roughness:.28}),edge=new T.MeshStandardMaterial({color:0xe6eef2,metalness:.8,roughness:.2}),gold=new T.MeshStandardMaterial({color:0xc79b52,metalness:.7,roughness:.35}),grip=new T.MeshStandardMaterial({color:0x374552,roughness:.95});
 function box(w,h,d,x,y,z,material){const m=new T.Mesh(new T.BoxGeometry(w,h,d),material);m.position.set(x,y,z);m.castShadow=true;root.add(m);return m;}
 const shape=new T.Shape();shape.moveTo(-.3,-.48);shape.lineTo(.3,-.48);shape.lineTo(.3,-2.52);shape.lineTo(0,-SWORD_LENGTH);shape.lineTo(-.3,-2.52);shape.closePath();
 const blade=new T.Mesh(new T.ExtrudeGeometry(shape,{depth:.085,bevelEnabled:true,bevelThickness:.025,bevelSize:.04,bevelSegments:1,steps:1}),steel);blade.position.z=-.0425;blade.castShadow=true;root.add(blade);
 box(.048,1.96,.02,0,-1.5,.073,edge);box(1.0,.14,.19,0,-.43,0,gold);box(.14,.49,.16,0,-.12,0,grip);box(.22,.18,.21,0,.17,0,gold);
 for(let i=0;i<5;i++)box(.156,.025,.174,0,-.31+i*.085,0,gold);

 const miniature=root.clone(true);miniature.visible=false;carrier.add(miniature);
 const thumbScene=new T.Scene(),thumbModel=root.clone(true);thumbModel.rotation.z=-.7;const center=new T.Box3().setFromObject(thumbModel).getCenter(new T.Vector3());thumbModel.position.sub(center);thumbScene.add(thumbModel);thumbScene.add(new T.HemisphereLight(0xffffff,0x7c8d9a,2.7));const keyLight=new T.DirectionalLight(0xfff3db,3);keyLight.position.set(-3,5,7);thumbScene.add(keyLight);
 const thumbCamera=new T.OrthographicCamera(-1.9,1.9,1.9,-1.9,.1,25);thumbCamera.position.set(2,1,8);thumbCamera.lookAt(0,0,0);
 const thumbRenderer=new T.WebGLRenderer({alpha:true,antialias:true,preserveDrawingBuffer:true});thumbRenderer.setSize(192,192);thumbRenderer.setClearColor(0x000000,0);thumbRenderer.toneMapping=T.ACESFilmicToneMapping;thumbRenderer.toneMappingExposure=.95;thumbRenderer.render(thumbScene,thumbCamera);const iconURL=thumbRenderer.domElement.toDataURL('image/png');thumbRenderer.dispose();thumbRenderer.forceContextLoss();
 let storedSlot=0;
 function setMount(slot){storedSlot=slot;miniature.scale.setScalar(.23);miniature.position.set((slot%2===0?1:-1)*.16,.95,-.68);miniature.rotation.set(0,Math.PI,slot%2===0?-.28:.28);miniature.visible=state==='stored';}
 let temporary=false;
 let state='world',body=makeSwordBody(),acc=0;
 const hand=new T.Vector3(),direction=new T.Vector3(),basis=new T.Matrix4(),axisY=new T.Vector3(),axisX=new T.Vector3(),axisZ=new T.Vector3(),worldUp=new T.Vector3(0,1,0);
 function render(){root.visible=state!=='stored'&&!temporary;miniature.visible=(state==='stored'&&storedSlot>=0&&storedSlot<5)||temporary;axisY.copy(body.a).sub(body.b).normalize();axisZ.copy(worldUp).addScaledVector(axisY,-worldUp.dot(axisY));if(axisZ.lengthSq()<.01)axisZ.set(0,0,1).addScaledVector(axisY,-axisY.z);axisZ.normalize();axisX.crossVectors(axisY,axisZ).normalize();basis.makeBasis(axisX,axisY,axisZ);root.quaternion.setFromRotationMatrix(basis);root.position.copy(body.a);}
 render();
 return {stowedPose(){return miniature.visible?{kind:'sword',position:miniature.position.toArray(),quaternion:miniature.quaternion.toArray(),scale:miniature.scale.toArray()}:null;},pose(){return {position:root.position.toArray(),quaternion:root.quaternion.toArray()};},
  kind:'sword',visualClone(){const model=root.clone(true);model.position.set(0,0,0);model.rotation.set(0,0,0);model.visible=true;return model;},get state(){return state;},get body(){return body;},iconURL,
  temporaryStow(value){temporary=value;setMount(storedSlot);render();},mount(slot){setMount(slot);},gripPoint(t){root.updateMatrixWorld(true);return root.localToWorld(new T.Vector3(0,-t,0));},
  near(p){return state==='world'&&Math.min(body.a.distanceTo(new T.Vector3(p.x,p.y+.5,p.z)),body.b.distanceTo(new T.Vector3(p.x,p.y+.5,p.z)))<2.25;},
  pickup(slot=0){state='stored';setMount(slot);render();},
  equip(anchor,heading){state='equipped';body.a.copy(anchor);body.b.copy(anchor).add(new T.Vector3(-Math.sin(heading)*2.9,-.2,-Math.cos(heading)*2.9));body.b.y=Math.max(.13,body.b.y);body.oldA.copy(body.a);body.oldB.copy(body.b);acc=0;render();},
  store(slot=storedSlot){state='stored';setMount(slot);render();},
  drop(p,heading){if(state!=='equipped'){body.a.set(p.x+Math.sin(heading)*1.1,p.y+.9,p.z+Math.cos(heading)*1.1);body.b.copy(body.a).add(new T.Vector3(Math.cos(heading)*SWORD_LENGTH,.25,-Math.sin(heading)*SWORD_LENGTH));}state='world';body.oldA.copy(body.a).add(new T.Vector3(-p.vx/120,-.012,-p.vz/120));body.oldB.copy(body.b).add(new T.Vector3(-p.vx/120,-.012,-p.vz/120));acc=0;render();},
  update(dt,p,handMesh,paused,aim=null){if(state==='stored'||paused||temporary){render();return;}acc+=dt;handMesh.getWorldPosition(hand);for(const b of blocks){const hx=b.w/2+.2,hz=b.d/2+.2;if(Math.abs(hand.x-b.x)<hx&&Math.abs(hand.z-b.z)<hz&&hand.y<b.h+.2){const dx=hx-Math.abs(hand.x-b.x),dz=hz-Math.abs(hand.z-b.z),dy=b.h+.2-hand.y;if(dy<Math.min(dx,dz))hand.y=b.h+.2;else if(dx<dz)hand.x=b.x+Math.sign(hand.x-b.x||1)*hx;else hand.z=b.z+Math.sign(hand.z-b.z||1)*hz;}}direction.set(p.vx,0,p.vz);while(acc>=1/120){if(aim&&state==='equipped'){const target=aim.clone().sub(hand).normalize().multiplyScalar(SWORD_LENGTH).add(hand);body.b.lerp(target,1-Math.exp(-9/120));body.oldB.lerp(body.b,.22);}
 stepSword(body,1/120,blocks,state==='equipped'?hand:null,direction,p);acc-=1/120;}render();}
 };
}
