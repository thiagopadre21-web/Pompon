export function collisionParts(b){
 if(!b.ladder&&!b.door)return [b];
 const base=b.baseY||0,height=b.h-base;const parts=[],add=(x,y,z,w,h,d)=>{const c=Math.cos(b.angle||0),s=Math.sin(b.angle||0);parts.push({x:b.x+x*c+z*s,z:b.z-x*s+z*c,w:Math.abs(w*c)+Math.abs(d*s),d:Math.abs(w*s)+Math.abs(d*c),h:base+y+h/2,yMin:base+y-h/2,parentBlock:b});};
 const width=b.rotated?b.d:b.w;
 if(b.ladder){for(const x of [-width/2+.07,width/2-.07])add(x,height/2,0,.14,height,.14);for(let y=.25;y<height;y+=.4)add(0,y,0,width-.14,.1,.14);}
 else{for(const x of [-width/2+.08,width/2-.08])add(x,height/2,0,.16,b.h,.3);add(0,height-.08,0,width,.16,.3);const turn=b.openAmount||0,a=turn*Math.PI*.5,len=width-.32;add(-width/2+.16+Math.cos(a)*len/2,(height-.18)/2,-Math.sin(a)*len/2,Math.abs(Math.cos(a))*len+.16*Math.abs(Math.sin(a)),height-.18,Math.abs(Math.sin(a))*len+.16*Math.abs(Math.cos(a)));}
 return parts;
}
