export function surfaceHeight(b,x,z){if(!b.ramp)return b.h;const t=b.rotated?(x-b.x)/b.w+.5:(z-b.z)/b.d+.5;return (b.baseY||0)+(b.h-(b.baseY||0))*Math.max(0,Math.min(1,t));}
