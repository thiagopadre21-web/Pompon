export function spring(value,velocity,target,dt,stiffness=100,damping=15){
 velocity+=((target-value)*stiffness-velocity*damping)*dt;
 return [value+velocity*dt,velocity];
}
export function createInput(){
 const held=new Set();
 return {held,down(code,repeat=false){if(repeat)return false;const fresh=!held.has(code);held.add(code);return fresh;},up(code){return held.delete(code);},clear(){held.clear();}};
}
