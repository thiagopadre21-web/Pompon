export function actionButton(twoHand,hand){return twoHand||hand===0?0:2;}
export function actionHeld(twoHand,hand,left,right){return actionButton(twoHand,hand)===0?left:right;}
