// The desktop host captures raw mouse counts while its game window is focused.
// Ordinary browser builds retain the browser's native Pointer Lock API.
let captured=null,pending=null;
const webview=globalThis.chrome?.webview;
export const desktopMouse=!!webview;
export function captureDesktopMouse(canvas){
 if(!webview)return Promise.reject(Error('Desktop host unavailable'));
 if(captured===canvas)return Promise.resolve();
 return new Promise((resolve,reject)=>{pending?.reject(Error('Capture replaced'));pending={canvas,resolve,reject};canvas.focus?.({preventScroll:true});webview.postMessage('pompon-capture');});
}
if(webview&&typeof document!=='undefined'){
 const descriptor=Object.getOwnPropertyDescriptor(Document.prototype,'pointerLockElement');
 const exit=document.exitPointerLock.bind(document);
 Object.defineProperty(document,'pointerLockElement',{configurable:true,get:()=>captured||descriptor?.get?.call(document)||null});
 document.exitPointerLock=()=>{if(captured||pending){webview.postMessage('pompon-release');pending?.reject(Error('Capture cancelled'));pending=null;captured=null;document.documentElement.classList.remove('desktop-mouse');document.dispatchEvent(new Event('pointerlockchange'));}else exit();};
 const style=document.createElement('style');style.textContent='.desktop-mouse,.desktop-mouse *{cursor:none!important}';document.head.append(style);
 webview.addEventListener('message',event=>{const m=event.data;if(!m||typeof m!=='object')return;
  if(m.type==='mouse'&&captured){const kind='onpointerrawupdate' in globalThis?'pointerrawupdate':'mousemove',e=new MouseEvent(kind,{bubbles:true});Object.defineProperties(e,{movementX:{value:m.x},movementY:{value:m.y},pomponNative:{value:true}});document.dispatchEvent(e);}
  if(m.type==='capture'){
   if(m.active&&pending){captured=pending.canvas;const done=pending;pending=null;document.documentElement.classList.add('desktop-mouse');document.dispatchEvent(new Event('pointerlockchange'));done.resolve();}
   else if(m.active){webview.postMessage('pompon-release');}
   else{const was=!!captured;captured=null;pending?.reject(Error(m.error||'No se pudo capturar el mouse'));pending=null;document.documentElement.classList.remove('desktop-mouse');if(was)document.dispatchEvent(new Event('pointerlockchange'));}
  }
 });
}
export function ignoreDesktopMotion(event){return !!captured&&!event.pomponNative;}
