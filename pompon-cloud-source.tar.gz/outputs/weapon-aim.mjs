import * as T from './vendor/three.module.js';
export function safeAimDirection(heading,cameraYaw,pitch,active){
 const wanted=active?cameraYaw+Math.PI:heading;
 const delta=Math.atan2(Math.sin(wanted-heading),Math.cos(wanted-heading));
 const angle=heading+T.MathUtils.clamp(delta,-.7,.7),elevation=active?T.MathUtils.clamp(-pitch,-1.5,1.5):-.08;
 return new T.Vector3(Math.sin(angle)*Math.cos(elevation),Math.sin(elevation),Math.cos(angle)*Math.cos(elevation));
}
