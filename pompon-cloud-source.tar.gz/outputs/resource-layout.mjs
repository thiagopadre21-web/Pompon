import {lakes} from './terrain-height.mjs';
export function resourceLayout(random=Math.random){const sites=[{x:38,z:32},{x:-40,z:-35}],nodes=[];
for(let attempt=0;sites.length<20&&attempt<3000;attempt++){const c={x:(random()-.5)*510,z:(random()-.5)*510};if(Math.hypot(c.x,c.z)<35||Math.abs(c.x)<18||Math.abs(c.z)<18||sites.some(s=>Math.hypot(s.x-c.x,s.z-c.z)<55))continue;sites.push(c);}
function add(x,z,type,site){if(lakes.some(l=>Math.hypot(x-l.x,z-l.z)<l.r+2)||Math.abs(x)>280||Math.abs(z)>280||Math.abs(x)<8||Math.abs(z)<8||Math.hypot(x,z)<24||nodes.some(n=>Math.hypot(n.x-x,n.z-z)<10))return false;nodes.push({x,z,type,site});return true;}
sites.forEach((c,index)=>{const count=index%5===0?3:2,angle=random()*Math.PI*2;for(let j=0;j<count;j++){const a=angle+j*Math.PI*2/count,r=8+random()*2;add(c.x+Math.cos(a)*r,c.z+Math.sin(a)*r,j%2,index);}});
for(let attempt=0,count=0;count<20&&attempt<2000;attempt++){const x=(random()-.5)*560,z=(random()-.5)*560;if(sites.some(c=>Math.hypot(x-c.x,z-c.z)<30)||nodes.some(n=>Math.hypot(x-n.x,z-n.z)<24))continue;if(add(x,z,count%2,-1))count++;}return nodes;
}
