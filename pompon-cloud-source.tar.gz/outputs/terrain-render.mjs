import * as T from './vendor/three.module.js';
// Keep the exact simulation grid; share its GPU attributes across culled sectors.
export function splitTerrain(mesh, cells=360, sector=30){
 const source=mesh.geometry, tiles=[];let version=-1,positionVersion=-1;
 source.setDrawRange(0,0);
 for(let z=0;z<cells;z+=sector)for(let x=0;x<cells;x+=sector){
  const width=Math.min(sector,cells-x),depth=Math.min(sector,cells-z),geometry=new T.BufferGeometry();
  for(const [name,attribute] of Object.entries(source.attributes))geometry.setAttribute(name,attribute);
  geometry.setIndex(new T.BufferAttribute(new Uint32Array(width*depth*6),1));
  const tile=new T.Mesh(geometry,mesh.material);tile.receiveShadow=mesh.receiveShadow;mesh.add(tile);tiles.push({tile,x,z,width,depth});
 }
 function update(){const indicesChanged=version!==source.index.version,positionsChanged=positionVersion!==source.attributes.position.version;if(!indicesChanged&&!positionsChanged)return;
  const pos=source.attributes.position;
  for(const {tile,x,z,width,depth} of tiles){const g=tile.geometry;
   if(indicesChanged){for(let row=0;row<depth;row++)g.index.array.set(source.index.array.subarray(((z+row)*cells+x)*6,((z+row)*cells+x+width)*6),row*width*6);g.index.needsUpdate=true;}
   if(positionsChanged){let min=Infinity,max=-Infinity;for(let row=z;row<=z+depth;row++)for(let col=x;col<=x+width;col++){const y=pos.getY(row*(cells+1)+col);min=Math.min(min,y);max=Math.max(max,y);}const a=z*(cells+1)+x,b=(z+depth)*(cells+1)+x+width;g.boundingBox=new T.Box3(new T.Vector3(pos.getX(a),min,Math.min(pos.getZ(a),pos.getZ(b))),new T.Vector3(pos.getX(b),max,Math.max(pos.getZ(a),pos.getZ(b))));g.boundingSphere=g.boundingBox.getBoundingSphere(new T.Sphere());}
  }version=source.index.version;positionVersion=pos.version;
 }
 update();return {update,tiles};
}
