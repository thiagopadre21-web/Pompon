import * as T from './vendor/three.module.js';
export function stepDebris(p,dt,blocks){
 p.life-=dt;p.vy-=25*dt;const oldY=p.y;p.x+=p.vx*dt;p.y+=p.vy*dt;p.z+=p.vz*dt;
 let floor=p.radius;
 for(const b of blocks){if(Math.abs(p.x-b.x)<b.w/2+p.radius&&Math.abs(p.z-b.z)<b.d/2+p.radius){if(oldY>=b.h+p.radius-.03)floor=Math.max(floor,b.h+p.radius);else if(p.y<b.h){const dx=b.w/2+p.radius-Math.abs(p.x-b.x),dz=b.d/2+p.radius-Math.abs(p.z-b.z);if(dx<dz){p.x=b.x+Math.sign(p.x-b.x||1)*(b.w/2+p.radius);p.vx*=-.35;}else{p.z=b.z+Math.sign(p.z-b.z||1)*(b.d/2+p.radius);p.vz*=-.35;}}}}
 if(p.y<floor){p.y=floor;p.vy=Math.abs(p.vy)>.6?-p.vy*.25:0;p.vx*=.65;p.vz*=.65;}
}
export function createDebris(scene,blocks){
 const brass=new T.MeshStandardMaterial({color:0xffcd65,metalness:.7,roughness:.3}),magMaterial=new T.MeshStandardMaterial({color:0x26343c,roughness:.6,metalness:.4});
 const particles=[];for(let i=0;i<38;i++){const magazine=i>=32,mesh=new T.Mesh(magazine?new T.BoxGeometry(.12,.34,.16):new T.CylinderGeometry(.028,.028,.115,7),magazine?magMaterial:brass);mesh.castShadow=true;mesh.visible=false;scene.add(mesh);particles.push({mesh,magazine,life:0,radius:magazine?.085:.03});}let shellIndex=0,magIndex=32;
 return {clear(){for(const p of particles){p.life=0;p.mesh.visible=false;}},emit(kind,position,velocity){const p=particles[kind==='magazine'?(magIndex++-32)%6+32:shellIndex++%32];Object.assign(p,{x:position.x,y:position.y,z:position.z,vx:velocity.x,vy:velocity.y,vz:velocity.z,life:kind==='magazine'?.95:.85});p.mesh.position.copy(position);p.mesh.rotation.set(Math.random()*3,Math.random()*3,Math.random()*3);p.mesh.scale.setScalar(1);p.mesh.visible=true;},update(dt){for(const p of particles){if(p.life<=0){p.mesh.visible=false;continue;}const n=Math.ceil(dt/(1/120));for(let i=0;i<n;i++)stepDebris(p,dt/n,blocks);p.mesh.position.set(p.x,p.y,p.z);p.mesh.rotation.x+=dt*9;p.mesh.rotation.z+=dt*7;p.mesh.scale.setScalar(Math.min(1,Math.max(0,p.life)/.12));p.mesh.visible=p.life>0;}}};
}
