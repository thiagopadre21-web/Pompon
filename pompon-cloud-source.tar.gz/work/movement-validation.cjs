// Broad safety limits allow ordinary movement and latency, but reject invalid or large teleports.
module.exports=function acceptMovement(player,pose,now=Date.now()){
 if(!pose||!['x','y','z'].every(k=>Number.isFinite(pose[k])&&Math.abs(pose[k])<310))return false;
 const before=player.pose,dt=Math.max(0,Math.min(.3,(now-(player.movementAt||player.seen||now))/1000));
 player.moveCredit=Math.min(6,(player.moveCredit??2)+dt*20);player.movementAt=now;
 const distance=before?Math.hypot(pose.x-before.x,pose.z-before.z):0;
 if(distance>player.moveCredit||before&&Math.abs(pose.y-before.y)>Math.max(3,dt*60)){player.poseCorrection=true;return false;}
 player.moveCredit-=distance;player.pose=pose;player.poseCorrection=false;return true;
};
