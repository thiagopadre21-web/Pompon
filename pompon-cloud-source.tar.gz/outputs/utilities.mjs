import * as T from './vendor/three.module.js';
import {itemModel} from './crafted-item.mjs';
import {utilityState,launchUtility,advanceUtility,flashStrength,SMOKE_RADIUS} from './utility-rules.mjs';
import {setSmokeEffects,clearThroughSmoke} from './smoke-visibility.mjs';
import {createThrowAction} from './throw-action.mjs';
import {sound} from './sound.mjs';
export function setupUtilities({scene,camera,blocks,inventory,online,getPlayer,getState,getDirection,isPaused}){
 const nodes=new Map(),seen=new Set(),dot=document.createElement('div'),flash=document.createElement('div'),hint=document.createElement('div');
 dot.id='utility-aim';flash.id='flash-screen';hint.id='utility-hint';dot.hidden=hint.hidden=true;flash.style.opacity=0;document.body.append(dot,flash,hint);
 const action=createThrowAction();let lastScope=null;let pending=false,blindUntil=0,blindFade=0,blindPeak=0,lastBeep=0,errorUntil=0;
 online.setOcclusion?.(point=>clearThroughSmoke(camera,point));
 const error=message=>{hint.textContent=message;errorUntil=Date.now()+3500;hint.hidden=false;};
 function equipped(){const hands=inventory.hands();const hand=hands[1]&&['flash','smoke','c4'].includes(hands[1])?1:hands.findIndex(k=>['flash','smoke','c4'].includes(k));return hand<0?null:{hand,kind:hands[hand],id:inventory.heldKey(hand)};}
 async function launch(a){if(pending||inventory.heldKey(a.hand)!==a.id)return;const d=a.direction,launchScope=lastScope;pending=true;
  try{if(online.active){if(!globalThis.pomponArena)await online.request('/api/tick',{items:inventory.networkChanges(),light:true});const args={kind:a.kind,item:a.id,direction:d,operation:crypto.randomUUID(),round:online.arena?.round};let result;try{result=await online.request('/api/utility',args);}catch{result=await online.request('/api/utility',args);}if(launchScope!==lastScope)return;if(globalThis.pomponArena)inventory.consumeKit(a.kind);else inventory.removeStored(a.id);if(result.remaining)inventory.receiveStored(result.remaining);}
  else{const result=launchUtility(utilityState(getState()),a.kind,getPlayer(),d,Date.now(),crypto.randomUUID(),blocks);if(result.error)throw Error(result.error);const entry=inventory.serialize(true).items.find(i=>i.id===a.id);inventory.removeStored(a.id);if(entry.count>1)inventory.receiveStored({...entry,id:crypto.randomUUID(),count:entry.count-1,cell:a.hand+3});}}
  catch(e){error(e.message);}finally{pending=false;}
 }
 function hide(){document.body.classList.remove("utility-equipped");action.cancel();setSmokeEffects([]);for(const root of nodes.values())root.visible=false;dot.hidden=hint.hidden=true;flash.style.opacity=0;blindUntil=0;blindPeak=0;}
 function handPoint(hand,heading){const pose=action.pose(hand);if(!pose)return null;const p=getPlayer(),side=hand===0?.55:-.55;return new T.Vector3(p.x+Math.cos(heading)*side+Math.sin(heading)*pose.back,p.y+pose.height,p.z-Math.sin(heading)*side+Math.cos(heading)*pose.back);}
 return {hide,handPoint,get aiming(){return action.state?.phase==='aim';},cancel:()=>action.cancel(),click(button){const a=equipped();if(!a||button!==0&&button!==2)return false;if(isPaused()||pending)return true;if(a.kind==='c4'){if(button===(a.hand===0?0:2))launch({...a,direction:getDirection()});return true;}if(button===2)action.begin(a.hand,a.id,a.kind);else if(action.state)action.release(getDirection());return true;},release(button){if(button===2)action.release(getDirection());},update(dt){
 const scope=globalThis.pomponArena?online.arena:null,key=scope?scope.id+':'+scope.round:'world';if(key!==lastScope){hide();seen.clear();lastScope=key;}const state=scope?(scope.utility||{projectiles:[],effects:[]}):utilityState(getState()),now=Date.now();for(const root of nodes.values())root.visible=true;
 action.update(dt,a=>!isPaused()&&(a.released||inventory.heldKey(a.hand)===a.id),launch);
 if(!online.active)advanceUtility(state,now,blocks,(uid,n)=>blocks.find(b=>b.uid===uid)?.damage?.(n));setSmokeEffects(state.effects);
 const visible=new Set();for(const g of state.projectiles){visible.add(g.id);let root=nodes.get(g.id);if(!root){root=itemModel(g.kind);scene.add(root);nodes.set(g.id,root);root.position.set(g.x,g.y,g.z);}root.position.lerp(new T.Vector3(g.x,g.y,g.z),online.active?1-Math.exp(-30*dt):1);if(g.kind!=='c4'){root.rotation.x+=dt*6;root.rotation.z+=dt*4;}else if(now-lastBeep>700){lastBeep=now;sound('beep',Math.max(0,1-camera.position.distanceTo(root.position)/25));}}
 for(const e of state.effects){if(!seen.has(e.id)){seen.add(e.id);if(now-e.at<1000){const position=new T.Vector3(e.x,e.y,e.z),distance=camera.position.distanceTo(position);sound(e.kind==='flash'?'flash':e.kind==='smoke'?'smoke':'explosion',Math.max(0,1-distance/100)**1.5);if(e.kind==='flash'&&clearThroughSmoke(camera,position)){const strength=flashStrength(e,camera.position,camera.getWorldDirection(new T.Vector3()),blocks);if(strength>0){const duration=200+strength*4300;blindPeak=1;blindUntil=Math.max(blindUntil,now+duration);blindFade=Math.min(1400,duration*.4);}}}}
  if(e.kind==='smoke'){const key=e.id+'-smoke';visible.add(key);let root=nodes.get(key);if(!root){root=new T.Group();const geo=new T.SphereGeometry(1,12,8),mat=new T.MeshStandardMaterial({color:0x939c96,roughness:1,side:T.DoubleSide});for(let i=0;i<7;i++){const puff=new T.Mesh(geo,mat);puff.position.set(Math.sin(i*2.4)*1.8,1.5+Math.cos(i)*.35,Math.cos(i*2.4)*1.8);puff.scale.setScalar(SMOKE_RADIUS-1.8);root.add(puff);}scene.add(root);nodes.set(key,root);}root.position.set(e.x,e.y,e.z);root.scale.setScalar(Math.max(.01,Math.min(1,(now-e.at)/800,(e.until-now)/1500)));}}
 for(const[key,root]of nodes)if(!visible.has(key)){scene.remove(root);const geometries=new Set(),materials=new Set();root.traverse(m=>{if(m.geometry)geometries.add(m.geometry);if(m.material)materials.add(m.material);});for(const g of geometries)g.dispose();for(const m of materials)m.dispose();nodes.delete(key);}
 const held=equipped();document.body.classList.toggle("utility-equipped",!!held);dot.hidden=isPaused()||!held;hint.hidden=isPaused()||!held;if(held&&now>errorUntil)hint.textContent=held.kind==='c4'?'Clic de la mano: colocar C4 · 150 de daño':action.state?.phase==='aim'?'Soltá clic derecho para lanzar':'Derecho: mantener y soltar · H: cambiar mano';
 flash.style.opacity=String(blindPeak*Math.min(1,Math.max(0,(blindUntil-now)/Math.max(1,blindFade))));if(seen.size>500)seen.clear();
 }};
}
