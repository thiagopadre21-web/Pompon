import {terrainHeight,waterLevel,terrainFloor,terrainCeiling,terrainSolid,terrainSurface} from './terrain-height.mjs';
import {collisionParts} from './structure-collision.mjs';
import {surfaceHeight} from './surfaces.mjs';
export const blocks = [
  {x:0,z:-10,w:12,d:1.2,h:5.5,color:0xb1a4d9},
  {x:-12,z:0,w:1.2,d:13,h:5,color:0xa3cbbb},
  {x:10,z:2,w:5,d:5,h:1.4,color:0xe7be97},
  {x:13,z:-5,w:4,d:4,h:2.8,color:0xe7be97},
  {x:-6,z:10,w:4,d:4,h:1.2,color:0xa3cbbb}
];
export function createPlayer(){return {x:0,y:0,z:5,vx:0,vy:0,vz:0,ground:true,jumps:1,grace:.1,buffer:0,lock:0,nx:0,nz:0,event:'',land:0,impact:0};}
const approach=(a,b,t)=>a<b?Math.min(a+t,b):Math.max(a-t,b);
export function step(p,ix,iz,dt){
 if(p.mantle){const m=p.mantle;m.t=Math.min(1,m.t+dt/.24);const t=m.t*m.t*(3-2*m.t);p.x=m.x+(m.tx-m.x)*t;p.z=m.z+(m.tz-m.z)*t;p.y=m.y+(m.ty-m.y)*t;p.vx=p.vy=p.vz=0;p.climbing=false;if(m.t===1){p.mantle=null;p.ground=true;p.climbCooldown=.35;}return;}
 p.event='';p.impact=0;p.lock=Math.max(0,p.lock-dt);p.grace=Math.max(0,p.grace-dt);p.land=Math.max(0,p.land-dt);
 const len=Math.hypot(ix,iz);if(len>1){ix/=len;iz/=len;}
 const accel=(p.lock>0?22:p.ground?(len?108:122):(len?70:20))*(p.heavy&&len?.78:1);
 const depth=waterLevel(p.x,p.z)-terrainHeight(p.x,p.z);p.wading=depth>.005&&p.y<waterLevel(p.x,p.z)+.2;const wetSlow=p.wading?Math.max(.45,.72-depth*.2):1;
 const speed=wetSlow*(p.swimming?4:p.sneaking?3.0:9.4)*(p.mobility??(p.heavy?.65:1));
 p.vx=approach(p.vx,ix*speed,accel*dt);p.vz=approach(p.vz,iz*speed,accel*dt);
 if(p.buffer>0 && (p.ground||p.grace>0||p.climbing)){
  if(p.climbing)p.climbCooldown=.3;p.vy=p.heavy?12.2:14.2;p.jumps=0;p.event='jump';
  p.ground=false;p.grace=0;p.buffer=0;
 }
 p.buffer=Math.max(0,p.buffer-dt);
 const wasGround=p.ground;const oldY=p.y,oldX=p.x,oldZ=p.z;p.x+=p.vx*dt;p.z+=p.vz*dt;p.vy=Math.max(-28.4,p.vy-56.4*dt);p.y+=p.vy*dt;
 if(oldY+.3<terrainSurface(oldX,oldZ)){const blocked=(x,z)=>[[.38,0],[-.38,0],[0,.38],[0,-.38]].some(([dx,dz])=>terrainSolid(x+dx,oldY+.35,z+dz)||terrainSolid(x+dx,oldY+.95,z+dz));if(blocked(p.x,oldZ))p.x=oldX;if(blocked(p.x,p.z))p.z=oldZ;}p.ground=false;p.nx=0;p.nz=0;

 p.climbCooldown=Math.max(0,(p.climbCooldown||0)-dt);const previousClimb=p.climbing;p.climbing=false;
 const ladder=p.canClimb&&p.climbCooldown===0&&blocks.find(b=>b.ladder&&Math.abs(p.x-b.x)<b.w/2+.9&&Math.abs(p.z-b.z)<b.d/2+.9&&(previousClimb||oldY<b.h-.05));
 if(ladder&&p.event!=='jump'&&p.event!=='wall'){
 const axis=ladder.rotated?'x':'z',tangent=ladder.rotated?'z':'x',half=(ladder.rotated?ladder.d:ladder.w)/2;
 const side=previousClimb?p.climbSide:Math.sign(p[axis]-ladder[axis])||-1,normalInput=(axis==='x'?ix:iz)*-side,tangentInput=tangent==='x'?ix:iz;
 if(previousClimb||normalInput>.15){p.climbSide=side;p.climbing=true;p[axis]=ladder[axis]+side*.73;
 p[tangent]-=p[tangent==='x'?'vx':'vz']*dt;p[tangent]+=tangentInput*3.4*dt;
 p.y=Math.max(0,oldY+normalInput*3.6*dt);p.climbMoving=Math.abs(normalInput)+Math.abs(tangentInput);p.vy=0;p.vx=p.vz=0;
 if(p.y>=ladder.h){p.mantle={t:0,x:p.x,z:p.z,y:p.y,tx:axis==='x'?ladder.x-side*.8:p.x,tz:axis==='z'?ladder.z-side*.8:p.z,ty:ladder.h+.02};p.climbing=false;}
 else if(p.y<=0&&normalInput<=0){p.climbing=false;p.climbCooldown=.2;p[axis]+=side*.08;}
 else if(Math.abs(p[tangent]-ladder[tangent])>half+.45){p.climbing=false;p.climbCooldown=.25;}
 }}else if(previousClimb)p.climbCooldown=.25;
  for(const original of blocks.flatMap(b=>b.door?collisionParts(b):[b])){if(p.y+1.1<(original.yMin||0))continue;if(original.ladder){if(!p.climbing&&!p.mantle&&p.y<original.h){const axis=original.rotated?'x':'z',tangent=original.rotated?'z':'x',width=original.rotated?original.d:original.w;if(Math.abs(p[tangent]-original[tangent])<width/2+.45&&Math.abs(p[axis]-original[axis])<.72){p[axis]=original[axis]+(Math.sign(p[axis]-original[axis])||-1)*.72;p[axis==='x'?'vx':'vz']=0;}}continue;}const b=original.ramp?{...original,h:surfaceHeight(original,p.x,p.z)}:original;
  const dx=p.x-b.x,dz=p.z-b.z,hx=b.w/2+.55,hz=b.d/2+.55;
  if(Math.abs(dx)<hx&&Math.abs(dz)<hz){
   if(((oldY>=b.h-.035)||(wasGround&&b.h-oldY<=.24))&&p.y<=b.h&&p.vy<=0){p.impact=Math.max(0,-p.vy);p.y=b.h;p.vy=0;p.ground=true;}
   else if(p.y<b.h-.01&&p.y+1.1>0){
    if(hx-Math.abs(dx)<hz-Math.abs(dz)){p.nx=dx>=0?1:-1;p.x=b.x+p.nx*hx;if(p.vx*p.nx<0)p.vx=0;}
    else {p.nz=dz>=0?1:-1;p.z=b.z+p.nz*hz;if(p.vz*p.nz<0)p.vz=0;}
   }
  }
  if(p.y<b.h-.01&&p.y+1.1>0){
   if(Math.abs(Math.abs(p.x-b.x)-hx)<.025&&Math.abs(p.z-b.z)<hz)p.nx=p.x>b.x?1:-1;
   if(Math.abs(Math.abs(p.z-b.z)-hz)<.025&&Math.abs(p.x-b.x)<hx)p.nz=p.z>b.z?1:-1;
  }
 }
 const groundY=terrainFloor(p.x,p.z,oldY);if(p.y<=groundY){p.impact=Math.max(0,-p.vy);if(p.vy<-7)p.land=.16;p.y=groundY;p.vy=0;p.ground=true;}
 if(wasGround)p.impact=0;
 if(p.ground){p.jumps=1;p.grace=.1;}
 const ceiling=terrainCeiling(p.x,p.z,oldY+.2);if(Number.isFinite(ceiling)&&p.y+1.1>ceiling&&ceiling-groundY>=1.1){p.y=ceiling-1.1;p.vy=Math.min(0,p.vy);}const water=waterLevel(p.x,p.z);if(water>groundY+.8&&p.y<water){p.swimming=true;const target=water-(p.swimDive?1.8:.65);p.vy=Math.max(-2.5,Math.min(2.5,(target-oldY)*3));if(p.swimUp)p.vy=2;p.y=Math.max(groundY,oldY+p.vy*dt);p.ground=false;}else p.swimming=false;
 if(Math.abs(p.x)>299){p.x=Math.sign(p.x)*299;p.vx=0;}if(Math.abs(p.z)>299){p.z=Math.sign(p.z)*299;p.vz=0;}
}
