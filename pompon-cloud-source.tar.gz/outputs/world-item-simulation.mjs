import * as T from './vendor/three.module.js';
import {stepSword} from './sword-physics.mjs';
import {setTerrain,setArenaTerrain} from './terrain-height.mjs';
// Fixed-step simulation; each room owns its bodies, never a connected player.
export function advanceWorldItems(room,elapsed){
 setArenaTerrain(false);setTerrain(room.farm?.digs||[],room.farm?.water||[],room.farm?.cuts||[]);
 room.itemBodies??=new Map();const bodies=room.itemBodies,blocks=[...room.buildings.values()];
 for(const [id,b] of bodies)if(room.items.get(id)!==b.entry||b.entry.owner||b.entry.state!=='world')bodies.delete(id);
 const environment=JSON.stringify([room.farm?.digs,room.farm?.cuts,blocks]);if(room.itemEnvironment!==environment){room.itemEnvironment=environment;for(const b of bodies.values())b.rest=0;}
 room.itemAccumulator=Math.min(.1,(room.itemAccumulator||0)+elapsed);
 while(room.itemAccumulator>=1/120){room.itemAccumulator-=1/120;
  for(const [id,item] of room.items){if(item.owner||item.state!=='world')continue;
   if(![item.a,item.b].every(v=>Array.isArray(v)&&v.length===3&&v.every(Number.isFinite)))continue;
   let body=bodies.get(id);if(!body){const a=new T.Vector3().fromArray(item.a),b=new T.Vector3().fromArray(item.b);body={entry:item,a,b,oldA:a.clone(),oldB:b.clone(),length:Math.max(.08,Math.min(4,a.distanceTo(b))),drag:.72,contact:false};bodies.set(id,body);}
   if(body.rest>=60)continue;const before=body.a.clone();stepSword(body,1/120,blocks);body.rest=body.contact&&before.distanceToSquared(body.a)<1e-9?(body.rest||0)+1:0;item.a=body.a.toArray();item.b=body.b.toArray();
  }
 }
}
