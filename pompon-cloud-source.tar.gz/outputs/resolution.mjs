export const resolutions=['1920x1080','1600x900','1280x720','1440x1080','1280x960','1080x1080','1024x768'];
let saved='';try{saved=globalThis.localStorage?.getItem('pompon-resolution')||'';}catch{}
const requested=new URLSearchParams(globalThis.location?.search||'').get('resolution')||saved;
export let fixedResolution=resolutions.includes(requested)?requested.split('x').map(Number):null;
export function setResolution(value){
 if(value!=='auto'&&!resolutions.includes(value))throw Error('Resolución no válida');
 fixedResolution=value==='auto'?null:value.split('x').map(Number);
 try{globalThis.localStorage?.setItem('pompon-resolution',value);}catch{}
 try{const url=new URL(location.href);if(value==='auto')url.searchParams.delete('resolution');else url.searchParams.set('resolution',value);history.replaceState(null,'',url);}catch{}
 globalThis.dispatchEvent(new Event('pompon-resolution-change'));
 globalThis.dispatchEvent(new Event('resize'));
}
export function renderSize(){return fixedResolution||[innerWidth,innerHeight];}
export function renderAspect(){const [w,h]=renderSize();return w/h;}
