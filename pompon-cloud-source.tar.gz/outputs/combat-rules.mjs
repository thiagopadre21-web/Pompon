export const weaponRange=kind=>({gun:180,rifle:350,sniper:600}[kind]||4.5);
export const nameplateRange=40;
