export function createInventoryState(){
 return {slots:[null,null,null],selected:0,equipped:-1,
  move(from,to){if(from===to||!this.slots[from]||to<0||to>2)return;[this.slots[from],this.slots[to]]=[this.slots[to],this.slots[from]];if(this.equipped===from)this.equipped=to;else if(this.equipped===to)this.equipped=from;this.selected=to;},
  remove(slot){const item=this.slots[slot];this.slots[slot]=null;if(this.equipped===slot)this.equipped=-1;return item;},
  get mobility(){return this.equipped>=0?.65:1;}
 };
}
