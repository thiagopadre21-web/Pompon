import {terrainSolid} from './terrain-height.mjs';
import {collisionParts} from './structure-collision.mjs';
import {solidHit} from './combat-physics.mjs';
import * as T from './vendor/three.module.js';
export const SMOKE_MS=18000,C4_DAMAGE=150,SMOKE_RADIUS=4.8;
export function utilityState(farm){return farm.utility??={projectiles:[],effects:[]};}
export function launchUtility(state,kind,pose,direction,now,id,blocks=[]){
 if(!['flash','smoke','c4'].includes(kind)||state.projectiles.length>=32)return {error:'No se puede usar ahora'};
 const d=new T.Vector3(direction?.x,direction?.y,direction?.z);if(!Number.isFinite(d.lengthSq())||d.lengthSq()<.1)return {error:'Dirección inválida'};d.normalize();const origin=new T.Vector3(pose.x,pose.y+1.05,pose.z);
 const g={id,kind,x:origin.x,y:origin.y,z:origin.z,vx:d.x*16+(pose.vx||0),vy:d.y*16+3.5,vz:d.z*16+(pose.vz||0),born:now,last:now,bounces:0};
 if(kind==='c4'){const hit=solidHit(origin,d,blocks,3);if(!hit?.block?.uid)return {error:'Apuntá a una estructura cercana para colocar la carga'};Object.assign(g,{x:hit.point.x,y:hit.point.y,z:hit.point.z,target:hit.block.uid,vx:0,vy:0,vz:0});}
 state.projectiles.push(g);return {ok:true,projectile:g};
}
export function stepProjectile(g,dt,blocks=[]){
 const r=.09;g.vy-=14*dt;for(const axis of ['x','y','z']){const velocity='v'+axis,old=g[axis],next=old+g[velocity]*dt;g[axis]=next;let collided=false;
 for(const original of blocks)for(const b of collisionParts(original)){if(g.x>b.x-b.w/2-r&&g.x<b.x+b.w/2+r&&g.z>b.z-b.d/2-r&&g.z<b.z+b.d/2+r&&g.y>(b.yMin||0)-r&&g.y<b.h+r){if(b.ramp){const a=b.rotated?'x':'z',span=b.rotated?b.w:b.d,top=(b.baseY||0)+(b.h-(b.baseY||0))*(g[a]-b[a]+span/2)/span;if(g.y>top+r)continue;}collided=true;break;}}
 if(terrainSolid(g.x,g.y-r,g.z))collided=true;if(collided){g[axis]=old;g[velocity]*=-.68;if(axis==='y'){g.vx*=.9;g.vz*=.9;if(Math.abs(g.vy)<.5)g.vy=0;}g.bounces++;}}
}
export function advanceUtility(state,now,blocks=[],damage=()=>{}){
 for(const g of state.projectiles){if(g.kind!=='c4'){let left=Math.min(.25,Math.max(0,(now-g.last)/1000));while(left>0){const dt=Math.min(left,1/120);stepProjectile(g,dt,blocks);left-=dt;}}g.last=now;const age=now-g.born;
 if(g.kind==='c4'?age>=5000:g.kind==='flash'?age>=2600:age>=2300&&Math.hypot(g.vx,g.vy,g.vz)<.35||age>=5000){g.done=true;state.effects.push({id:g.id,kind:g.kind,x:g.x,y:g.y,z:g.z,at:now,until:now+(g.kind==='smoke'?SMOKE_MS:6000)});if(g.kind==='c4')damage(g.target,C4_DAMAGE);}}
 state.projectiles=state.projectiles.filter(g=>!g.done);state.effects=state.effects.filter(e=>e.until>now);
}
export function flashStrength(effect,eye,look,blocks=[]){const delta=new T.Vector3(effect.x-eye.x,effect.y-eye.y,effect.z-eye.z),distance=delta.length();if(distance>=100)return 0;const d=delta.normalize(),facing=d.dot(look);if(facing<.6||solidHit(new T.Vector3(eye.x,eye.y,eye.z),d,blocks,Math.max(0,distance-.2)))return 0;return Math.max(0,1-(Math.max(0,distance-8)/92)**2)**2*Math.min(1,facing*1.7)/(1+(Math.max(0,distance-8)/25)**2);}
export function smokeBlocks(effects,origin,target,now=Date.now()){const segment=new T.Line3(new T.Vector3(origin.x,origin.y,origin.z),new T.Vector3(target.x,target.y,target.z));return effects.some(e=>{const center=new T.Vector3(e.x,e.y+1.5,e.z);return e.kind==='smoke'&&e.until>now&&segment.closestPointToPoint(center,true,new T.Vector3()).distanceToSquared(center)<SMOKE_RADIUS**2;});}
