import {damagePlayer} from './armor-rules.mjs';
import * as T from './vendor/three.module.js';
import {solidHit} from './combat-physics.mjs';
import {smokeBlocks} from './utility-rules.mjs';
export const TURRET_RANGE=28,TURRET_DAMAGE=25,TURRET_INTERVAL=600;
export function advanceTurrets(room,now,onKill=()=>{}){
 const blocks=[...room.buildings.values()];
 for(const b of blocks){if(b.id!=='turret'||b.hp<=0||!b.ownerId||now-(b.lastShot||0)<TURRET_INTERVAL)continue;
 const owner=room.players.get(b.ownerId),saved=Object.values(room.savedPlayers||{}).find(p=>p.id===b.ownerId),clan=owner?owner.clan:saved?saved.clan:b.ownerClan;
 const origin=new T.Vector3(b.x,(b.baseY||0)+1.25,b.z);let chosen=null,distance=TURRET_RANGE;
 for(const p of room.players.values()){if(p.id===b.ownerId||p.health<=0||p.arenaId||owner?.team&&p.team===owner.team||clan&&p.clan===clan)continue;
 const target=new T.Vector3(p.pose.x,p.pose.y+.65,p.pose.z),d=origin.distanceTo(target);if(d>distance)continue;
 if(smokeBlocks(room.farm?.utility?.effects||[],origin,target,now))continue;
 const direction=target.clone().sub(origin).normalize();if(solidHit(origin,direction,blocks.filter(x=>x!==b),Math.max(0,d-.35)))continue;
 chosen=p;distance=d;
 }
 if(chosen){b.lastShot=now;b.aimX=chosen.pose.x;b.aimY=chosen.pose.y+.65;b.aimZ=chosen.pose.z;damagePlayer(room,chosen,TURRET_DAMAGE);if(chosen.health===0)onKill(chosen,owner);}
 }
}
