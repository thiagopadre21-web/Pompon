class VoiceCapture extends AudioWorkletProcessor{
 constructor(){super();this.enabled=false;this.samples=[];this.phase=0;this.port.onmessage=e=>{this.enabled=!!e.data;this.samples=[];};}
 process(inputs){const input=inputs[0]?.[0];if(!this.enabled||!input)return true;for(const sample of input){this.phase+=16000/sampleRate;if(this.phase>=1){this.phase-=1;this.samples.push(Math.max(-32767,Math.min(32767,Math.round(sample*32767))));if(this.samples.length===2048){const pcm=new Int16Array(this.samples);this.port.postMessage(pcm.buffer,[pcm.buffer]);this.samples=[];}}}return true;}
}
registerProcessor('pompon-voice',VoiceCapture);
