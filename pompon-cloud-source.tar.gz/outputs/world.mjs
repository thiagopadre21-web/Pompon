import {terrainHeight} from './terrain-height.mjs';
import {resourceLayout} from './resource-layout.mjs';
import * as T from './vendor/three.module.js';
export function addResources(scene,blocks,obstacles){const wood=new T.MeshStandardMaterial({color:0x825331,roughness:1}),cut=new T.MeshStandardMaterial({color:0xcda66c,roughness:1}),stone=new T.MeshStandardMaterial({color:0x879590,roughness:1});const nodes=[];
 for(const spot of [...resourceLayout(seedRandom()),...ironSpots,...coalSpots]){const {x,z,type}=spot,group=new T.Group();group.position.set(x,terrainHeight(x,z),z);group.userData.resourceType=type===3?'coal':type===2?'iron':type?'stone':'wood';group.userData.site=spot.site;group.userData.hitTime=0;scene.add(group);nodes.push(group);const h=type?1.6:4.5,w=type?2.2:.85,d=type?2:.85;
 if(type){for(let j=0;j<3;j++){const mesh=new T.Mesh(new T.DodecahedronGeometry(j===0?1.05:.65,0),type===3?new T.MeshStandardMaterial({color:0x30353b,roughness:.9}):type===2?new T.MeshStandardMaterial({color:0x8c6553,metalness:.65,roughness:.45}):stone);mesh.position.set(j===0?0:(j===1?-.7:.65),j===0?.85:.45,j===2?.4:0);mesh.scale.set(1.15,1,.85);mesh.rotation.set(.12*j,.8*j,.1*j);mesh.castShadow=true;group.add(mesh);obstacles.push(mesh);}}
 else{const trunk=new T.Mesh(new T.CylinderGeometry(.29,.43,3,9),wood);trunk.position.y=1.5;trunk.castShadow=true;group.add(trunk);obstacles.push(trunk);for(let j=0;j<4;j++){const foliage=new T.Mesh(new T.IcosahedronGeometry(1.45,1),new T.MeshStandardMaterial({color:[0x477d3b,0x619544,0x739f48,0x558638][j],roughness:1}));foliage.position.set(j===0?0:Math.sin(j*2.4)*.9,3.4+(j===0?.9:0),j===0?0:Math.cos(j*2.4)*.9);foliage.castShadow=true;group.add(foliage);}for(let j=0;j<4;j++){const apple=new T.Mesh(new T.SphereGeometry(.12,8,6),new T.MeshStandardMaterial({color:0xc94d3f}));apple.position.set(Math.sin(j*2)*1.2,2.8+(j%2)*.4,Math.cos(j*2)*1.2);group.add(apple);}}
 blocks.push({x,z,w,d,h:h+terrainHeight(x,z),yMin:terrainHeight(x,z),resource:true,resourceType:type===3?'coal':type===2?'iron':type?'stone':'wood',node:group});}
 return nodes;
}

export const ironSpots=[{x:65,z:80,type:2},{x:-90,z:110,type:2},{x:160,z:-120,type:2},{x:-180,z:-165,type:2},{x:230,z:205,type:2}];
function seedRandom(){let n=72891;return()=>{n=(1664525*n+1013904223)>>>0;return n/4294967296;};}

export const coalSpots=[{x:45,z:62,type:3},{x:-78,z:-100,type:3}];
