// Camera input is consumed once per rendered frame. Pointer-lock transitions and
// window focus may produce synthetic deltas; they must not become camera turns.
export function createCameraInput(options={}){let x=0,y=0,skip=0;return {reset(discard=1){x=y=0;skip=discard;},push(dx,dy,sensitivity=.003){if(!Number.isFinite(dx)||!Number.isFinite(dy))return;if(skip>0){skip--;return;}x+=dx*sensitivity;y+=dy*sensitivity;},consume(){const limit=Infinity,dx=Math.max(-limit,Math.min(limit,x)),dy=Math.max(-limit,Math.min(limit,y));x=y=0;return {x:dx,y:dy};}};}
export function cameraDistance(current,target,dt){if(target<current)return target;return current+(target-current)*(1-Math.exp(-8*Math.min(.05,Math.max(0,dt))));}

// Raw pointer events avoid display-rate event coalescing. Never subscribe to
// raw and normal motion simultaneously while captured (that doubles sensitivity).
export function cameraMotionEvent(target=globalThis){return 'onpointerrawupdate' in target?'pointerrawupdate':'mousemove';}
