// Cloud directory and room lifecycle. Gameplay rules stay in the shared server.
const crypto=require('crypto');
module.exports=function cloudRooms(rooms,{version,region='oregon',maxRooms=30,officialRoom=true}={}){
 const codes=new Map(),limits=new Map();
 const summary=(id,r)=>({id,name:r.name,players:r.players.size,maxPlayers:r.maxPlayers,serverType:'cloud',visibility:r.visibility,worldMode:'survival',version,region,online:true,official:!!r.official});
 function erase(id){const r=rooms.get(id);if(r?.official)return false;if(r){codes.delete(r.code);for(const p of r.players.values())p.motionStream?.end();rooms.delete(id);}}
 function sweep(now=Date.now()){for(const[id,r]of rooms){if(r.serverType!=='cloud')continue;for(const[pid,p]of r.players)if(now-p.seen>20000){p.motionStream?.end();r.players.delete(pid);}if(!r.players.has(r.host))r.host=r.players.keys().next().value||null;if(r.players.size)r.emptySince=null;else{r.emptySince??=now;if(!r.official&&now-r.emptySince>120000)erase(id);}}for(const[ip,v]of limits)if(now-v.at>60000)limits.delete(ip);}
 function route(path,body,ip){sweep();if(path==='/api/cloud/rooms')return {rooms:[...rooms].filter(([,r])=>r.serverType==='cloud'&&r.visibility==='public').map(([id,r])=>summary(id,r))};
 if(path==='/api/cloud/resolve'){const id=codes.get(String(body.code||'').trim().toUpperCase());if(!id||!rooms.has(id))return {error:'Código inexistente o sala cerrada',status:404};return {room:summary(id,rooms.get(id))};}
 if(path!=='/api/cloud/create')return null;
 if(body.version!==version)return {error:'Actualizá el juego para entrar a este servicio',status:409};
 if(!['public','private'].includes(body.visibility))return {error:'Visibilidad inválida',status:400};
 const now=Date.now(),limit=limits.get(ip)||{at:now,count:0};if(++limit.count>6)return {error:'Esperá un minuto antes de crear otra sala',status:429};limits.set(ip,limit);
 if(rooms.size>=maxRooms)return {error:'El servicio está completo. Reintentá más tarde',status:503};
 const id=crypto.randomBytes(24).toString('hex');let code;do{code='POM-'+crypto.randomBytes(6).toString('hex').toUpperCase();}while(codes.has(code));
 const r={serverType:'cloud',visibility:body.visibility,code,created:now,emptySince:now,name:String(body.name||'Partida cloud').trim().slice(0,48)||'Partida cloud',maxPlayers:Math.max(2,Math.min(20,Math.floor(Number(body.maxPlayers)||10))),worldMode:'survival',host:null,players:new Map(),items:new Map(),buildings:new Map(),clans:new Map(),savedPlayers:{}};
 rooms.set(id,r);codes.set(code,id);return {room:summary(id,r),code};
 }
 if(officialRoom){const id='pompon-oficial';rooms.set(id,{official:true,serverType:'cloud',visibility:'public',code:null,created:Date.now(),emptySince:null,name:'Pompón Oficial · Supervivencia',maxPlayers:10,worldMode:'survival',host:null,players:new Map(),items:new Map(),buildings:new Map(),clans:new Map(),savedPlayers:{}});}
 const timer=setInterval(sweep,5000);timer.unref();return {route,sweep,erase};
};
