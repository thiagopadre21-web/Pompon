import * as T from './vendor/three.module.js';
import {recipes} from './crafting.mjs';
import {robotWorker} from './worker-robot.mjs';
export function structureModel(kind){
 const r=recipes[kind],root=new T.Group(),material=new T.MeshStandardMaterial({color:r.color||0x97806a,roughness:.85});
 const box=(w,h,d,x,y,z,mat=material,parent=root)=>{const m=new T.Mesh(new T.BoxGeometry(w,h,d),mat);m.position.set(x,y,z);m.castShadow=m.receiveShadow=true;parent.add(m);return m;};
 if(r.turret){const dark=new T.MeshStandardMaterial({color:0x202e33}),gun=new T.Group();box(1.1,.18,1.1,0,.09,0);box(.24,.85,.24,0,.55,0,dark);gun.position.y=1.25;root.add(gun);box(.65,.38,.55,0,0,0,material,gun);box(.12,.12,.9,0,0,.65,dark,gun);const muzzle=box(.2,.2,.18,0,0,1.15,new T.MeshBasicMaterial({color:0xffda67}),gun);muzzle.visible=false;root.userData.turretHead=gun;root.userData.turretFlash=muzzle;}else if(r.chest){const band=new T.MeshStandardMaterial({color:0x3c4546});box(1.4,.12,.85,0,.06,0);for(const x of [-.64,.64])box(.12,.64,.85,x,.4,0);for(const z of [-.365,.365])box(1.4,.64,.12,0,.4,z);const lid=new T.Group();lid.position.set(0,.75,-.425);root.add(lid);box(1.44,.16,.9,0,0,.425,material,lid);for(const x of [-.48,.48])box(.09,.18,.92,x,0,.425,band,lid);box(.15,.22,.06,0,.61,.45,band);root.userData.chestLid=lid;}
 else if(r.resourceType){const base=box(1,.62,.8,0,.65,0);root.userData.worker=robotWorker(base,r.resourceType);root.userData.worker.update(0,false);}
 else if(r.ladder){for(const x of [-r.w/2+.07,r.w/2-.07])box(.14,r.h,.14,x,r.h/2,0);for(let y=.25;y<r.h;y+=.4)box(r.w-.14,.1,.14,0,y,0);}
 else if(r.door){box(.16,r.h,.3,-r.w/2+.08,r.h/2,0);box(.16,r.h,.3,r.w/2-.08,r.h/2,0);box(r.w,.16,.3,0,r.h-.08,0);const pivot=new T.Group();pivot.position.set(-r.w/2+.16,0,0);root.add(pivot);box(r.w-.32,r.h-.18,.16,(r.w-.32)/2,(r.h-.18)/2,0,material,pivot);box(.09,.1,.13,r.w-.5,1,.14,new T.MeshStandardMaterial({color:0xd4bb7b}),pivot);root.userData.doorPivot=pivot;}
 else if(r.ramp){const shape=new T.Shape();shape.moveTo(-r.d/2,0);shape.lineTo(r.d/2,0);shape.lineTo(r.d/2,r.h);shape.closePath();const geo=new T.ExtrudeGeometry(shape,{depth:r.w,bevelEnabled:false});geo.translate(0,0,-r.w/2);const m=new T.Mesh(geo,material);m.rotation.y=-Math.PI/2;root.add(m);}
 else box(r.w,r.h,r.d,0,r.h/2,0);
 return root;
}
