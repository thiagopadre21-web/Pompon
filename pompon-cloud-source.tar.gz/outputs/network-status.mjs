export function networkLabel({active=false,cloud=false,hosting=false,ping=null,lastReply=0,failed=false}={},now=performance.now()) {
 if(!active)return 'Local: sin conexión multijugador';
 const place=cloud?'Cloud':hosting?'Host PC':'Servidor PC';
 if(failed||(lastReply>0&&now-lastReply>5000))return place+' · Sin respuesta del servidor';
 return place+(Number.isFinite(ping)?' · Ping '+Math.round(ping)+' ms':' · Midiendo ping…');
}
