import {terrainHeight,waterLevel,setTerrain,setArenaTerrain} from './terrain-height.mjs';
export const CHECKPOINT_RADIUS=7;
export function safeSpawn(x,z,blocks=[],players=[]){
 if(Math.abs(x)>285||Math.abs(z)>285)return null;
 const y=terrainHeight(x,z);if(!Number.isFinite(y)||waterLevel(x,z)>y+.05)return null;
 for(const[dx,dz]of [[.65,0],[-.65,0],[0,.65],[0,-.65]])if(Math.abs(terrainHeight(x+dx,z+dz)-y)>.35)return null;
 if(blocks.some(b=>b.hp!==0&&Math.abs(x-b.x)<(b.w||1)/2+.65&&Math.abs(z-b.z)<(b.d||1)/2+.65&&(b.baseY||0)<y+1.3&&(b.h||1)+(b.baseY||0)>y-.1))return null;
 if(players.some(p=>p.health>0&&p.pose&&Math.hypot(x-p.pose.x,z-p.pose.z)<1.4&&Math.abs(y-p.pose.y)<1.5))return null;
 return {x,y:y+.03,z};
}
export function checkpointSpots(b,blocks=[],players=[]){const points=[];for(const radius of [3,5,7])for(let i=0;i<16;i++){const a=i*Math.PI/8,p=safeSpawn(b.x+Math.sin(a)*radius,b.z+Math.cos(a)*radius,blocks,players);if(p)points.push(p);}return points;}
export function belongs(b,p,players=new Map(),saved={}){const owner=players.get(b.ownerId)||Object.values(saved).find(x=>x.id===b.ownerId);const clan=owner?owner.clan:b.ownerClan,team=owner?owner.team:b.ownerTeam;return b.ownerId===p.id||!!clan&&clan===p.clan||!!team&&team===p.team;}
export function registerCheckpoint(room,b,player,old){if(old){for(const key of ['ownerId','ownerClan','ownerTeam','checkpointActive','placedAt'])b[key]=old[key];return;}Object.assign(b,{ownerId:player.id,ownerClan:player.clan||null,ownerTeam:player.team||null,checkpointActive:true,placedAt:Date.now()});for(const previous of room.buildings.values())if(previous.id==='checkpoint'&&belongs(previous,player,room.players,room.savedPlayers))previous.checkpointActive=false;}
export function respawnPosition(room,player,random=Math.random){setArenaTerrain(false);setTerrain(room.farm?.digs||[],room.farm?.water||[],room.farm?.cuts||[]);const blocks=[...room.buildings.values()],players=[...room.players.values()].filter(p=>p.id!==player.id),checkpoint=blocks.filter(b=>b.id==='checkpoint'&&b.hp>0&&b.checkpointActive!==false&&belongs(b,player,room.players,room.savedPlayers)).sort((a,b)=>(b.placedAt||0)-(a.placedAt||0))[0];if(checkpoint){const spots=checkpointSpots(checkpoint,blocks,players);if(spots.length)return spots[Math.min(spots.length-1,Math.floor(random()*spots.length))];}for(let i=0;i<400;i++){const p=safeSpawn((random()-.5)*540,(random()-.5)*540,blocks,players);if(p)return p;}for(let x=-280;x<=280;x+=8)for(let z=-280;z<=280;z+=8){const p=safeSpawn(x,z,blocks,players);if(p)return p;}return null;}
