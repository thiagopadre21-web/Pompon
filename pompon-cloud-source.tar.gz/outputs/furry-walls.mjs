import * as T from './vendor/three.module.js';

// Instanced pompons and a single fiber mesh keep the wall covering lightweight.
export function addFurryWalls(scene,blocks){
 let seed=314159;const random=()=>{seed=(1664525*seed+1013904223)>>>0;return seed/4294967296;};
 const pompoms=[],fibers=[],fiberColors=[];
 const baseColor=new T.Color(),fiberColor=new T.Color();
 function surface(b,origin,u,v,n,width,height){
  const cols=Math.max(1,Math.round(width/.46)),rows=Math.max(1,Math.round(height/.46));
  for(let row=0;row<rows;row++)for(let col=0;col<cols;col++){
   const radius=Math.min(width/cols,height/rows)*.51;
   const center=origin.clone().addScaledVector(u,(col+.5)*width/cols).addScaledVector(v,(row+.5)*height/rows).addScaledVector(n,.017);
   baseColor.set(b.color).lerp(new T.Color(0xfff0e2),.1+random()*.24);
   pompoms.push({center,u,v,n,radius,color:baseColor.clone()});
   for(let i=0;i<10;i++){
    const angle=random()*Math.PI*2,z=.12+random()*.88,r=Math.sqrt(1-z*z),a=Math.cos(angle)*r,c=Math.sin(angle)*r;
    const root=center.clone().addScaledVector(u,a*radius).addScaledVector(v,c*radius).addScaledVector(n,z*.105);
    const tip=root.clone().addScaledVector(u,a*.037).addScaledVector(v,c*.037+.008).addScaledVector(n,z*(.025+random()*.024));
    fibers.push(root.x,root.y,root.z,tip.x,tip.y,tip.z);
    fiberColor.copy(baseColor).lerp(new T.Color(0xfffaf1),.18+random()*.17);
    for(let k=0;k<2;k++)fiberColors.push(fiberColor.r,fiberColor.g,fiberColor.b);
   }
  }
 }
 for(const b of blocks.filter(b=>b.h>=5)){
  const {x,z,w,d,h}=b;
  surface(b,new T.Vector3(x-w/2,0,z+d/2),new T.Vector3(1,0,0),new T.Vector3(0,1,0),new T.Vector3(0,0,1),w,h);
  surface(b,new T.Vector3(x+w/2,0,z-d/2),new T.Vector3(-1,0,0),new T.Vector3(0,1,0),new T.Vector3(0,0,-1),w,h);
  surface(b,new T.Vector3(x+w/2,0,z+d/2),new T.Vector3(0,0,-1),new T.Vector3(0,1,0),new T.Vector3(1,0,0),d,h);
  surface(b,new T.Vector3(x-w/2,0,z-d/2),new T.Vector3(0,0,1),new T.Vector3(0,1,0),new T.Vector3(-1,0,0),d,h);
 }
 const canvas=document.createElement('canvas');canvas.width=canvas.height=128;const ctx=canvas.getContext('2d'),data=ctx.createImageData(128,128);
 for(let i=0;i<data.data.length;i+=4){const value=90+Math.floor(random()*140);data.data[i]=data.data[i+1]=data.data[i+2]=value;data.data[i+3]=255;}ctx.putImageData(data,0,0);
 const fuzz=new T.CanvasTexture(canvas);fuzz.wrapS=fuzz.wrapT=T.RepeatWrapping;fuzz.repeat.set(2,2);
 const material=new T.MeshStandardMaterial({color:0xffffff,roughness:1,bumpMap:fuzz,bumpScale:.022});
 const mesh=new T.InstancedMesh(new T.SphereGeometry(1,8,5),material,pompoms.length),matrix=new T.Matrix4(),rotation=new T.Matrix4(),quaternion=new T.Quaternion();
 for(let i=0;i<pompoms.length;i++){const p=pompoms[i];rotation.makeBasis(p.u,p.v,p.n);quaternion.setFromRotationMatrix(rotation);matrix.compose(p.center,quaternion,new T.Vector3(p.radius,p.radius,.105));mesh.setMatrixAt(i,matrix);mesh.setColorAt(i,p.color);}
 mesh.receiveShadow=true;mesh.instanceMatrix.needsUpdate=true;scene.add(mesh);
 const geometry=new T.BufferGeometry();geometry.setAttribute('position',new T.Float32BufferAttribute(fibers,3));geometry.setAttribute('color',new T.Float32BufferAttribute(fiberColors,3));
 const strands=new T.LineSegments(geometry,new T.LineBasicMaterial({vertexColors:true,transparent:true,opacity:.62,depthWrite:false}));scene.add(strands);
 return {pompoms:pompoms.length,fibers:fibers.length/6};
}
