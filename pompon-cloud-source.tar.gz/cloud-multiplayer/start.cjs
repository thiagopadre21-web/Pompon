const {checkRegion}=require('./region.cjs');
checkRegion(process.env.POMPON_REGION);
process.env.POMPON_SERVER_TYPE='cloud';
require('./runtime/work/multiplayer-server.cjs');
