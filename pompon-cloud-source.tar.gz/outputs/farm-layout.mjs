import {resourceLayout} from './resource-layout.mjs';
export function treeSpots(){let n=72891;return resourceLayout(()=>{n=(1664525*n+1013904223)>>>0;return n/4294967296;}).filter(s=>s.type===0);}
