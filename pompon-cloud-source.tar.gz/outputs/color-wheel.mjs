export function hsvToHex(h,s,v){
 const f=n=>{const k=(n+h/60)%6;return Math.round((v-v*s*Math.max(0,Math.min(k,4-k,1)))*255).toString(16).padStart(2,'0');};return '#'+f(5)+f(3)+f(1);
}
export function hexToHsv(hex){
 const rgb=[1,3,5].map(i=>parseInt(hex.slice(i,i+2),16)/255),[r,g,b]=rgb,max=Math.max(...rgb),min=Math.min(...rgb),d=max-min;
 let h=d===0?0:max===r?60*((g-b)/d%6):max===g?60*((b-r)/d+2):60*((r-g)/d+4);return {h:(h+360)%360,s:max===0?0:d/max,v:max};
}
export function setupColorWheel(onChange){
 const canvas=document.getElementById('color-wheel'),ctx=canvas.getContext('2d'),light=document.getElementById('color-light'),hexInput=document.getElementById('color-hex'),swatch=document.getElementById('color-swatch');
 let initial='#f5cbb7';try{const saved=localStorage.getItem('pompon-color');if(/^#[0-9a-f]{6}$/i.test(saved))initial=saved;}catch{}
 let {h,s,v}=hexToHsv(initial),dragging=false;
 const base=document.createElement('canvas');base.width=base.height=256;const bctx=base.getContext('2d'),pixels=bctx.createImageData(256,256);
 for(let y=0;y<256;y++)for(let x=0;x<256;x++){const dx=x-128,dy=y-128,r=Math.hypot(dx,dy),i=(y*256+x)*4;if(r>124)continue;const color=hsvToHex((Math.atan2(dy,dx)*180/Math.PI+360)%360,Math.min(1,r/124),1);pixels.data[i]=parseInt(color.slice(1,3),16);pixels.data[i+1]=parseInt(color.slice(3,5),16);pixels.data[i+2]=parseInt(color.slice(5,7),16);pixels.data[i+3]=255;}bctx.putImageData(pixels,0,0);
 function render(){
  ctx.clearRect(0,0,256,256);ctx.drawImage(base,0,0);ctx.fillStyle=`rgba(0,0,0,${1-v})`;ctx.beginPath();ctx.arc(128,128,124,0,Math.PI*2);ctx.fill();
  const x=128+Math.cos(h*Math.PI/180)*s*124,y=128+Math.sin(h*Math.PI/180)*s*124;ctx.beginPath();ctx.arc(x,y,6,0,Math.PI*2);ctx.strokeStyle='#ffffff';ctx.lineWidth=3;ctx.stroke();ctx.strokeStyle='#273d36';ctx.lineWidth=1;ctx.stroke();
  const hex=hsvToHex(h,s,v);hexInput.value=hex;hexInput.setCustomValidity('');swatch.style.background=hex;light.value=Math.round(v*100);canvas.setAttribute('aria-valuenow',Math.round(h));canvas.setAttribute('aria-valuetext',hex);onChange(hex);try{localStorage.setItem('pompon-color',hex);}catch{}
 }
 function select(event){const r=canvas.getBoundingClientRect(),dx=(event.clientX-r.left)*256/r.width-128,dy=(event.clientY-r.top)*256/r.height-128;h=(Math.atan2(dy,dx)*180/Math.PI+360)%360;s=Math.min(1,Math.hypot(dx,dy)/124);render();}
 canvas.addEventListener('pointerdown',e=>{if(e.button!==0)return;e.preventDefault();dragging=true;canvas.setPointerCapture(e.pointerId);select(e);});canvas.addEventListener('pointermove',e=>{if(dragging)select(e);});for(const type of ['pointerup','pointercancel','lostpointercapture'])canvas.addEventListener(type,()=>dragging=false);
 canvas.addEventListener('keydown',e=>{if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.code))return;e.preventDefault();if(e.code==='ArrowLeft')h=(h+355)%360;if(e.code==='ArrowRight')h=(h+5)%360;if(e.code==='ArrowUp')s=Math.min(1,s+.025);if(e.code==='ArrowDown')s=Math.max(0,s-.025);render();});
 light.addEventListener('input',()=>{v=Number(light.value)/100;render();});hexInput.addEventListener('input',()=>{if(/^#[0-9a-f]{6}$/i.test(hexInput.value)){({h,s,v}=hexToHsv(hexInput.value));render();}else hexInput.setCustomValidity('Ingresá un color como #f5cbb7');});
 document.getElementById('color-default').onclick=()=>{({h,s,v}=hexToHsv('#f5cbb7'));render();};render();
}
