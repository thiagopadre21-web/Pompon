import {solidHit} from './combat-physics.mjs';
import {nameplateRange} from './combat-rules.mjs';
import * as T from './vendor/three.module.js';
// Intersect the rendered body parts in their own space, including lean and animation.
export function avatarHit(ray,meshes,max,radius=0){let best=null;for(const mesh of meshes){mesh.updateWorldMatrix(true,false);const inverse=mesh.matrixWorld.clone().invert(),localRay=ray.clone().applyMatrix4(inverse),scale=mesh.getWorldScale(new T.Vector3()),extra=radius/Math.max(.05,Math.min(scale.x,scale.y,scale.z)),local=localRay.intersectSphere(new T.Sphere(new T.Vector3(),1+extra),new T.Vector3());if(!local)continue;const point=local.applyMatrix4(mesh.matrixWorld),distance=ray.origin.distanceTo(point);if(distance<max&&(!best||distance<best.distance))best={point,distance};}return best;}

export function nameplateVisibility(camera,position,viewer,blocks){const distance=Math.hypot(position.x-viewer.x,position.y-viewer.y,position.z-viewer.z);if(distance>=nameplateRange)return 0;const target=position.clone().add(new T.Vector3(0,.7,0)),direction=target.sub(camera.position),length=direction.length();if(solidHit(camera.position,direction.normalize(),blocks,Math.max(0,length-.4)))return 0;return Math.min(1,(nameplateRange-distance)/4);}
