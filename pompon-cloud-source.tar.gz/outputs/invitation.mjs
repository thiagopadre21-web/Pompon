export function invitationURL(value,resolution=''){
 let url;try{url=new URL(String(value).trim());}catch{throw Error('Pegá el link completo que te dio el anfitrión.');}
 if(!['http:','https:'].includes(url.protocol)||url.username||url.password||!/^\/peluche-v\d+\.html$/.test(url.pathname)||! /^[a-zA-Z0-9_-]{1,128}$/.test(url.searchParams.get('room')||''))throw Error('Ese link no es una invitación válida de Pompón.');
 const room=url.searchParams.get('room');url.search='';url.hash='';url.searchParams.set('room',room);if(resolution)url.searchParams.set('resolution',resolution);return url;
}
