export const CELL=602/360;
export const columnAt=(x,z)=>[Math.floor((x+301)/CELL),Math.floor((z+301)/CELL)];
export const cellCenter=c=>({x:(c.ix+.5)*CELL-301,y:c.y+.5,z:(c.iz+.5)*CELL-301});
const cache=new WeakMap();export function cutSet(cuts){let entry=cache.get(cuts);if(!entry||entry.length!==cuts.length){entry={length:cuts.length,set:new Set(cuts.map(c=>c.ix+','+c.y+','+c.iz))};cache.set(cuts,entry);}return entry.set;}
export function removed(cuts,x,y,z){const[ix,iz]=columnAt(x,z);return cutSet(cuts).has(ix+','+Math.floor(y)+','+iz);}
export function floorInCuts(x,z,reference,top,cuts){let y=Math.min(top,reference+.04);if(!cuts.length)return top;for(let i=0;i<7;i++){if(!removed(cuts,x,y-.001,z))return y===Math.min(top,reference+.04)?top:y;y=Math.floor(y-.001);}return y;}
export function ceilingInCuts(x,z,y,top,cuts){if(y>=top)return Infinity;for(let i=0;i<7;i++){if(!removed(cuts,x,y,z))return y;y=Math.floor(y)+1;if(y>=top)return Infinity;}return Infinity;}
export function digCell(s,point,top,horizontal=false){s.cuts??=[];const[ix,iz]=columnAt(point.x,point.z),bottom=Math.floor(point.y);const made=[];for(const y of horizontal?[bottom,bottom+1]:[bottom]){if(y<top-5||y>=top||s.cuts.length>=600)continue;if(s.cuts.some(c=>c.ix===ix&&c.iz===iz&&c.y===y))continue;const c={ix,iz,y};s.cuts.push(c);made.push(c);}return made.length;}
