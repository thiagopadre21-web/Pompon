import {wildWheat} from './wild-wheat.mjs';
import {digCell,cellCenter} from './terrain-cuts.mjs';
import {growCrops,cropProgress} from './crop-growth.mjs';
import {terrainHeight,terrainSurface,setTerrain,waterCell,waterLevel,advanceWater,ensureWaterSources,removeWaterSource} from './terrain-height.mjs';
export const GROW_MS=4*60*60*1000;
export const COW_GROW_MS=20*60*1000;
export const foodValues={apple:22,cookedmeat:48,rawmeat:10,wheat:5};
export function progress(planted,now=Date.now()){return Math.max(0,Math.min(1,(now-planted)/GROW_MS));}
export function createFarm(now=Date.now()){return {version:1,wheatRevision:1,layoutRevision:2,last:now,cows:Array.from({length:6},(_,i)=>({id:'cow-'+i,x:[22,-38,65,-90,120,-145][i],z:[23,35,-48,-60,85,110][i],hp:60,born:now-COW_GROW_MS,ready:0,cooldown:0,leash:null})),crops:wildWheat(now),drops:[],apples:{},receipts:[],serial:0};}
function drop(s,kind,count,x,z,now,source){s.drops.push({id:'drop-'+(++s.serial),kind,count,x,z,y:kind==='apple'?3:.4,vy:0,vx:Math.sin(s.serial*2.4)*.5,vz:Math.cos(s.serial*2.4)*.5,source,at:now});}
export function advanceFarm(s,now,players={},obstacles=[],trees=[]){setTerrain(s.digs||[],s.water||[],s.cuts||[]);const dt=Math.max(0,Math.min(.15,(now-s.last)/1000));s.digs??=[];if(!s.cropTick||now-s.cropTick>=1000){growCrops(s,now);s.cropTick=now;}s.last=now;s.waterDt=(s.waterDt||0)+dt;if(s.waterDt>=.1){advanceWater(s,Math.min(.2,s.waterDt),obstacles);s.waterDt=0;}const blocked=(x,z,r=.8)=>waterLevel(x,z,s.water,s.digs)>terrainHeight(x,z,s.digs)+.3||obstacles.some(b=>!b.ramp&&b.h>.3&&Math.abs(x-b.x)<b.w/2+r&&Math.abs(z-b.z)<b.d/2+r);
 for(const c of [...s.cows]){
 const owner=players[c.leash];if(c.leash&&(!owner||s.cows.filter(m=>m.leash===c.leash).indexOf(c)>=(owner.leashCount||0)||Math.hypot(owner.x-c.x,owner.z-c.z)>12))c.leash=null;
 let tx=c.x,tz=c.z,speed=0;
 let mate=c.ready>now?s.cows.find(m=>m.id===c.mate&&m.ready>now):null;if(!mate&&c.ready>now){c.mate=null;mate=s.cows.filter(m=>m!==c&&m.ready>now&&m.cooldown<=now&&(!m.mate||m.mate===c.id)&&Math.hypot(m.x-c.x,m.z-c.z)<100).sort((a,b)=>Math.hypot(a.x-c.x,a.z-c.z)-Math.hypot(b.x-c.x,b.z-c.z))[0];if(mate){c.mate=mate.id;mate.mate=c.id;}}
 if(mate){tx=mate.x;tz=mate.z;speed=1.25;}else if(c.leash&&owner){const peers=s.cows.filter(m=>m.leash===c.leash),i=peers.indexOf(c),a=(owner.heading||0)+Math.PI+(i-(peers.length-1)/2)*.7;tx=owner.x+Math.sin(a)*2.3;tz=owner.z+Math.cos(a)*2.3;speed=Math.min(3.5,Math.hypot(tx-c.x,tz-c.z)*1.2);}
 
 else{if(!c.nextTurn||now>c.nextTurn){c.walkCycle=(c.walkCycle||0)+1;const phase=c.x*.31+c.z*.17+c.walkCycle*2.399;c.tx=c.x+Math.sin(phase)*5;c.tz=c.z+Math.cos(phase)*5;c.nextTurn=now+7000+(Math.abs(Math.sin(phase))*5000);c.restUntil=now+2000;}if(now>c.restUntil){tx=c.tx;tz=c.tz;speed=.65;}}
 const dx=tx-c.x,dz=tz-c.z,d=Math.hypot(dx,dz);if(d<.3)speed=0;let vx=d?dx/d*speed:0,vz=d?dz/d*speed:0;
 for(const other of s.cows)if(other!==c){const ox=c.x-other.x,oz=c.z-other.z,dist=Math.hypot(ox,oz),min=(now-c.born<COW_GROW_MS?.55:1)+(now-other.born<COW_GROW_MS?.55:1);if(dist<min+.3){const angle=Number(c.id.replace(/\D/g,''))*2.4;vx+=(dist>.001?ox/dist:Math.sin(angle))*(min+.3-dist)*2;vz+=(dist>.001?oz/dist:Math.cos(angle))*(min+.3-dist)*2;}}
 if(speed>0&&blocked(c.x+vx*.8,c.z+vz*.8)){let best=null;const angle=Math.atan2(vx,vz);for(const turn of [.5,-.5,1,-1,1.5,-1.5,2,-2]){const ax=Math.sin(angle+turn),az=Math.cos(angle+turn);if(!blocked(c.x+ax*1.3,c.z+az*1.3)){best={vx:ax*speed,vz:az*speed};break;}}if(best){vx=best.vx;vz=best.vz;}}const smooth=1-Math.exp(-3.5*dt);c.vx=(c.vx||0)+(vx-(c.vx||0))*smooth;c.vz=(c.vz||0)+(vz-(c.vz||0))*smooth;
 if(!blocked(c.x+c.vx*dt,c.z))c.x+=c.vx*dt;else{c.vx=0;c.nextTurn=0;}if(!blocked(c.x,c.z+c.vz*dt))c.z+=c.vz*dt;else{c.vz=0;c.nextTurn=0;}c.x=Math.max(-290,Math.min(290,c.x));c.z=Math.max(-290,Math.min(290,c.z));c.moving=Math.hypot(c.vx,c.vz);c.stride=(c.stride||0)+c.moving*dt*5;
 if(c.moving>.05){const wanted=Math.atan2(c.vx,c.vz),delta=Math.atan2(Math.sin(wanted-(c.angle||0)),Math.cos(wanted-(c.angle||0)));c.angle=(c.angle||0)+delta*(1-Math.exp(-3*dt));}
 if(mate&&Math.hypot(mate.x-c.x,mate.z-c.z)<2.4&&s.cows.length<48){c.loveUntil=mate.loveUntil=now+4500;c.courtship??=now;mate.courtship??=now;if(now-Math.min(c.courtship,mate.courtship)<3000)continue;const birth=Array.from({length:16},(_,i)=>({x:(c.x+mate.x)/2+Math.sin(i*Math.PI/8)*2.2,z:(c.z+mate.z)/2+Math.cos(i*Math.PI/8)*2.2})).find(b=>!blocked(b.x,b.z)&&s.cows.every(o=>Math.hypot(o.x-b.x,o.z-b.z)>1.3));if(!birth)continue;c.ready=mate.ready=0;c.mate=mate.mate=null;c.courtship=mate.courtship=null;c.cooldown=mate.cooldown=now+300000;s.cows.push({id:'calf-'+(++s.serial),x:birth.x,z:birth.z,born:now,hp:60,ready:0,cooldown:now+COW_GROW_MS,leash:null});}
 }
 // Resolve overlaps independently of steering, including coincident saved positions.
 for(let pass=0;pass<3;pass++)for(let i=0;i<s.cows.length;i++)for(let j=i+1;j<s.cows.length;j++){const a=s.cows[i],b=s.cows[j],dx=b.x-a.x,dz=b.z-a.z,d=Math.hypot(dx,dz),min=(now-a.born<COW_GROW_MS?.5:.85)+(now-b.born<COW_GROW_MS?.5:.85);if(d<min){const nx=d>.001?dx/d:1,nz=d>.001?dz/d:0,k=(min-d)/2;a.x-=nx*k;a.z-=nz*k;b.x+=nx*k;b.z+=nz*k;}}
 for(const [i,t]of trees.entries()){const key=String(i);s.apples[key]??=now+45000+i%7*18000;if(now>=s.apples[key]){if(s.drops.filter(d=>d.source===key).length<3)drop(s,'apple',1,t.x+Math.sin(i)*1.4,t.z+Math.cos(i)*1.4,now,key);s.apples[key]=now+90000+(i%5)*25000;}}
 for(const d of s.drops){d.vy-=9.8*dt;d.y=Math.max(-.02,d.y+d.vy*dt);if(d.y===-.02)d.vy=0;d.x+=d.vx*dt;d.z+=d.vz*dt;d.vx*=Math.exp(-5*dt);d.vz*=Math.exp(-5*dt);for(const p of Object.values(players)){const dx=d.x-p.x,dz=d.z-p.z,l=Math.hypot(dx,dz);if(l<.7&&l>.01){d.vx+=dx/l*dt*8;d.vz+=dz/l*dt*8;}}}
}
export function farmAction(s,a,player,pose,now=Date.now(),random=Math.random,obstacles=[]){if(!a||typeof a.id!=='string')return null;setTerrain(s.digs||[],s.water||[],s.cuts||[]);s.digs??=[];s.water??=[];const old=s.receipts.find(r=>r.id===a.id);if(old)return old;const result={id:a.id,player,ok:false,cost:{},reward:{}};const near=(o,r=3.6)=>o&&Math.hypot(o.x-pose.x,o.z-pose.z)<=r;const cow=s.cows.find(c=>c.id===a.target),crop=s.crops.find(c=>c.id===a.target),loot=s.drops.find(d=>d.id===a.target);
 if(a.type==='plant'&&s.crops.length<80&&Number.isFinite(a.x)&&Number.isFinite(a.z)&&near(a)&&waterLevel(a.x,a.z,s.water,s.digs)<=terrainHeight(a.x,a.z,s.digs)&&Math.abs(a.x)<290&&Math.abs(a.z)<290&&!s.crops.some(c=>Math.hypot(c.x-a.x,c.z-a.z)<.7)&&!obstacles.some(b=>Math.abs(b.x-a.x)<b.w/2+.5&&Math.abs(b.z-a.z)<b.d/2+.5)){s.crops.push({id:'crop-'+(++s.serial),x:a.x,z:a.z,planted:now});result.cost.seed=1;result.ok=true;}
 if(a.type==='dig'&&near(a,3.6)&&Number.isFinite(a.x)&&Number.isFinite(a.z)&&Number.isFinite(a.y)&&!obstacles.some(b=>Math.hypot(b.x-a.x,b.z-a.z)<Math.max(b.w,b.d)/2+.4)){const n=digCell(s,a,terrainSurface(a.x,a.z,s.digs),!!a.horizontal);if(n){result.reward.dirt=n;result.ok=true;}}
 if(a.type==='fillDirt'){const c=s.cuts?.find(c=>c.ix===a.ix&&c.iz===a.iz&&c.y===a.y);if(c){const center=cellCenter(c);if(near(center)&&Math.hypot(center.x-pose.x,center.z-pose.z)>1.1){s.cuts=s.cuts.filter(v=>v!==c);result.cost.dirt=1;result.ok=true;}}}
 if(a.type==='fill'&&['bucket','wateringcan'].includes(a.kind)&&Number.isFinite(a.x)&&Number.isFinite(a.z)&&near(a)&&waterLevel(a.x,a.z,s.water,s.digs)>terrainHeight(a.x,a.z,s.digs)+.1){result.fluid={kind:a.kind,amount:a.kind==='bucket'?2:5};result.ok=true;}
 if(a.type==='water'&&near(crop)){crop.watered=now;crop.moisture=100;result.fluid={kind:'wateringcan',amount:-1,relative:true};result.ok=true;}
 if(a.type==='pour'&&near(a)&&Number.isFinite(a.x)&&Number.isFinite(a.z)&&s.water.length<1500){ensureWaterSources(s);const {x,z}=waterCell(a.x,a.z),id='water-'+(++s.serial);s.waterSources.push({id,x,z});let c=s.water.find(c=>c.x===x&&c.z===z);if(!c){c={x,z,volume:0,sources:{}};s.water.push(c);}c.volume+=2;c.sources[id]=2;result.fluid={kind:'bucket',amount:0};result.ok=true;}
 if(a.type==='removeWater'){const source=s.waterSources?.find(c=>c.id===a.target);if(near(source)&&removeWaterSource(s,a.target)){result.fluid={kind:'bucket',amount:2};result.ok=true;}}
 if(a.type==='trample'&&near(crop,1.2)){drop(s,'seed',1,crop.x,crop.z,now);s.crops=s.crops.filter(c=>c!==crop);result.ok=true;}
 if(a.type==='harvest'&&near(crop)&&cropProgress(crop,now)===1){result.reward={wheat:2+Math.floor(random()*2),seed:2};s.crops=s.crops.filter(c=>c!==crop);result.ok=true;}
 if(a.type==='pickup'&&near(loot)){result.reward[loot.kind]=loot.count;s.drops=s.drops.filter(d=>d!==loot);result.ok=true;}
 if(a.type==='feed'&&near(cow)&&now-cow.born>=COW_GROW_MS&&cow.cooldown<=now&&cow.ready<=now){cow.ready=now+600000;result.cost.wheat=1;result.ok=true;}
 if(a.type==='leash'&&near(cow)&&(!cow.leash||cow.leash===player)&&(cow.leash===player||s.cows.filter(c=>c.leash===player).length<(pose.leashCount||0))){cow.leash=cow.leash?null:player;result.ok=true;}
 if(a.type==='hit'&&near(cow,a.range||4)){cow.hp=Math.max(0,cow.hp-Math.min(100,Math.max(0,a.damage||0)));result.ok=true;if(cow.hp===0){s.cows=s.cows.filter(c=>c!==cow);drop(s,'leather',1+Math.floor(random()*3),cow.x-.35,cow.z,now);drop(s,'rawmeat',1+Math.floor(random()*3),cow.x+.35,cow.z,now);}}
 if(a.type==='release'){for(const c of s.cows)if(c.leash===player)c.leash=null;result.ok=true;}
 if(a.type==='eat'&&foodValues[a.kind]){result.cost[a.kind]=1;result.food=foodValues[a.kind];result.ok=true;}
 if(result.fluid)result.fluid.itemId=a.itemId;s.receipts.push(result);if(s.receipts.length>150)s.receipts.shift();return result;
}

export function releaseLeashes(s,owner){for(const c of s.cows||[])if(!owner||c.leash===owner)c.leash=null;}

export function migrateFarm(s,now=Date.now()){if(!s||s.version!==1)return createFarm(now);if(s.layoutRevision!==2){const fresh=createFarm(now);for(const c of s.cows){const spawn=fresh.cows.find(n=>n.id===c.id);if(spawn){c.x=spawn.x;c.z=spawn.z;c.vx=c.vz=0;c.nextTurn=0;}}s.layoutRevision=2;}if(s.wheatRevision!==1){s.crops=[...(s.crops||[]).filter(c=>!c.id.startsWith('wild-')),...wildWheat(now)];s.wheatRevision=1;}releaseLeashes(s);s.last=now;return s;}
