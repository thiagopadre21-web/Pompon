import {terrainHeight} from './terrain-height.mjs';
import {collisionParts} from './structure-collision.mjs';
import {surfaceHeight} from './surfaces.mjs';
import * as T from './vendor/three.module.js';
export const SWORD_LENGTH=3.05;
const gravity=new T.Vector3(0,-42,0);
export function makeSwordBody(){const a=new T.Vector3(1.4,.14,3.5),b=new T.Vector3(3.8,.14,1.618);b.sub(a).setLength(SWORD_LENGTH).add(a);return {a,b,oldA:a.clone(),oldB:b.clone(),contact:false};}
function pushOut(point,blocks){
 const corrected=point.clone();corrected.y=Math.max(terrainHeight(corrected.x,corrected.z)+.115,corrected.y);
 for(const original of blocks){if(original.ladder)continue;const b=original.ramp?{...original,h:surfaceHeight(original,point.x,point.z)}:original;const minX=b.x-b.w/2-.11,maxX=b.x+b.w/2+.11,minZ=b.z-b.d/2-.11,maxZ=b.z+b.d/2+.11;
  if(corrected.x>minX&&corrected.x<maxX&&corrected.z>minZ&&corrected.z<maxZ&&corrected.y<b.h+.115&&corrected.y>(b.yMin||0)-.1){
   const moves=[{d:corrected.x-minX,k:'x',v:minX},{d:maxX-corrected.x,k:'x',v:maxX},{d:corrected.z-minZ,k:'z',v:minZ},{d:maxZ-corrected.z,k:'z',v:maxZ},{d:b.h+.115-corrected.y,k:'y',v:b.h+.115}];moves.sort((a,b)=>a.d-b.d);corrected[moves[0].k]=moves[0].v;
  }
 }
 corrected.x=T.MathUtils.clamp(corrected.x,-299.7,299.7);corrected.z=T.MathUtils.clamp(corrected.z,-299.7,299.7);return corrected.sub(point);
}
export function stepSword(body,dt,blocks,anchor=null,trailDirection=null,player=null){
 if(body.remote&&!anchor)return;
 blocks=blocks.flatMap(collisionParts).filter(b=>Math.abs(b.x-(body.a.x+body.b.x)/2)<b.w/2+5&&Math.abs(b.z-(body.a.z+body.b.z)/2)<b.d/2+5);
 for(const [key,old] of [['a','oldA'],['b','oldB']]){
  const point=body[key],previous=body[old],velocity=point.clone().sub(previous).multiplyScalar(body.contact?(body.drag??.72):.995);previous.copy(point);point.add(velocity).addScaledVector(gravity,dt*dt);
 }
 body.contact=false;body.npcContact=false;let playerContact=false;
 if(anchor){body.a.copy(anchor);body.oldA.copy(anchor);if(trailDirection&&trailDirection.lengthSq()>.1){const target=anchor.clone().addScaledVector(trailDirection.clone().normalize(),-SWORD_LENGTH);target.y=Math.max(.115,anchor.y-2);body.b.addScaledVector(target.sub(body.b),Math.min(.1,dt*.85));}}
 for(let iteration=0;iteration<12;iteration++){
  const delta=body.b.clone().sub(body.a),length=delta.length();if(length<.0001)delta.set(0,0,1);
  const correction=delta.multiplyScalar((length-(body.length||SWORD_LENGTH))/Math.max(length,.0001));
  if(anchor)body.b.sub(correction);else{body.a.addScaledVector(correction,.5);body.b.addScaledVector(correction,-.5);}
  for(let i=0;i<=12;i++){
   const t=i/12,q=body.a.clone().lerp(body.b,t),push=pushOut(q,blocks);
   if(player){const offset=q.clone().sub(new T.Vector3(player.x,player.y+.55,player.z)),r=anchor?.79:.68,len=offset.length();if(len<r){if(len<.001)offset.set(1,0,0);else offset.divideScalar(len);push.addScaledVector(offset,r-len);playerContact=true;}}for(const c of player?.hurtSpheres||[]){const offset=q.clone().sub(new T.Vector3(c.x,c.y,c.z)),len=offset.length(),radius=c.r+.19;if(len<radius){if(len<.001)offset.set(1,0,0);else offset.divideScalar(len);push.addScaledVector(offset,radius-len);body.npcContact=true;}}if(push.lengthSq()<1e-12)continue;body.contact=true;
   if(anchor){if(t>.08)body.b.addScaledVector(push,Math.min(8,1/t));}else{const weight=(1-t)*(1-t)+t*t;body.a.addScaledVector(push,(1-t)/weight);body.b.addScaledVector(push,t/weight);}
  }
  if(anchor)body.a.copy(anchor);
 }
 if(playerContact&&!anchor&&player){const impulse=new T.Vector3(player.vx,0,player.vz).multiplyScalar(dt*.16);body.oldA.sub(impulse);body.oldB.sub(impulse);}
 // Contacts dissipate tangential motion so dropped items settle rather than hover.
 if(body.contact&&!anchor){for(const [key,old] of [['a','oldA'],['b','oldB']]){const velocity=body[key].clone().sub(body[old]);if(velocity.lengthSq()<.000015)velocity.set(0,0,0);body[old].copy(body[key]).addScaledVector(velocity,-(body.drag??.55));}}
}
