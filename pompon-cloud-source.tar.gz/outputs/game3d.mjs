import {setupProgression} from './progression.mjs';
import {renderSize,renderAspect,fixedResolution} from './resolution.mjs';
import {ignoreDesktopMotion} from './desktop-input.mjs';
import {setupUtilities} from './utilities.mjs';
import {setupChests} from './chests.mjs';
import {cameraOffset,MATCH_FOV,MATCH_SIGHT_Y,DEFAULT_CAMERA_DISTANCE,DEFAULT_CAMERA_PITCH} from './aim-camera.mjs';
import {splitTerrain} from './terrain-render.mjs';
import {createSensitivity,captureRawMouse} from './sensitivity.mjs';
import {setupTraining} from './training.mjs';
import {setupSpectator} from './spectator.mjs';
import {setupMainMenu} from './main-menu.mjs';
import {menuBackground} from './menu-background.mjs';
import {createFarm} from './farm-rules.mjs';
import {setupPlayers} from './session-players.mjs';
import {setupArena} from './arena.mjs';
import {setupVoice} from './voice.mjs';
import {setupSound} from './sound.mjs';
import {setupWater} from './water.mjs';
import {setupInterface,preferences} from './interface.mjs';
import {createHair} from './hair.mjs';
import {setupFarm} from './farm.mjs';
import {terrainFloor,terrainHeight} from './terrain-height.mjs';
import {cameraMotionEvent,createCameraInput,cameraDistance} from './camera-input.mjs';
import {setupSupply} from './supply.mjs';
import {setupChat} from './chat.mjs';
import {setupMultiplayer} from './multiplayer.mjs';
import {itemModel} from './crafted-item.mjs';
import {setupControls} from './controls.mjs';
import {actionButton,actionHeld} from './action-input.mjs';
import {harvest} from './crafting.mjs';
import {setupBuilding} from './building.mjs';
import {addResources} from './world.mjs';
import {setupDisplay} from './display-settings.mjs';
import {createVitals,sprint} from './vitals.mjs';
import {createNPC} from './npc.mjs';
import {collideItems,solidHit} from './combat-physics.mjs';
import * as T from './vendor/three.module.js';
import {blocks,createPlayer,step} from './physics.mjs';
import {spring,createInput} from './motion.mjs';
import {blinkClosure} from './blink.mjs';
import {setupColorWheel} from './color-wheel.mjs';
import {addFurryWalls} from './furry-walls.mjs';
import {createSword} from './sword.mjs';
import {setupInventory} from './inventory.mjs';
import {createGun} from './gun.mjs';
import {setupCrosshair} from './crosshair.mjs';
import {safeAimDirection} from './weapon-aim.mjs';
const scene=new T.Scene();scene.background=new T.Color(0xe8eee5);scene.fog=new T.Fog(0xe8eee5,38,95);
let renderer;let frontEnd=null;
try{renderer=new T.WebGLRenderer({antialias:true,powerPreference:'high-performance'});}catch(e){const el=document.getElementById('error');el.style.display='block';el.textContent='No se pudo iniciar el modo 3D. Probá abrir este juego en Chrome o Edge.';throw e;}
renderer.setPixelRatio(fixedResolution?1:Math.min(devicePixelRatio,1.6));renderer.setSize(...renderSize(),false);Object.assign(renderer.domElement.style,{width:"100%",height:"100%"});renderer.shadowMap.enabled=true;renderer.shadowMap.type=T.PCFSoftShadowMap;renderer.outputColorSpace=T.SRGBColorSpace;renderer.setClearColor(0xe8eee5);document.body.prepend(renderer.domElement);
renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=.85;
const camera=new T.PerspectiveCamera(MATCH_FOV,renderAspect(),.1,150);
scene.add(new T.HemisphereLight(0xffffff,0x9fafa0,2.5));const sun=new T.DirectionalLight(0xfff0d8,3);sun.position.set(-12,25,12);sun.castShadow=true;sun.shadow.mapSize.set(2048,2048);Object.assign(sun.shadow.camera,{left:-30,right:30,top:30,bottom:-30,far:70});sun.shadow.bias=-.0003;sun.shadow.normalBias=.03;scene.add(sun);
const mat=(color)=>new T.MeshStandardMaterial({color,roughness:.95});
const terrainGeo=new T.PlaneGeometry(602,602,360,360);terrainGeo.rotateX(-Math.PI/2);const terrainPos=terrainGeo.attributes.position;for(let i=0;i<terrainPos.count;i++)terrainPos.setY(i,terrainHeight(terrainPos.getX(i),terrainPos.getZ(i))-.015);terrainGeo.computeVertexNormals();const ground=new T.Mesh(terrainGeo,mat(0x789954));ground.receiveShadow=true;scene.add(ground);const terrainRender=splitTerrain(ground);
const grid=new T.GridHelper(50,25,0xabc2a5,0xb4cbae);grid.position.y=.006;grid.material.transparent=true;grid.material.opacity=.4;grid.visible=false;scene.add(grid);
const obstacleMeshes=[];
for(const b of blocks){const mesh=new T.Mesh(new T.BoxGeometry(b.w,b.h,b.d),mat(b.color));mesh.position.set(b.x,b.h/2,b.z);mesh.castShadow=true;mesh.receiveShadow=true;scene.add(mesh);obstacleMeshes.push(mesh);const cap=new T.Mesh(new T.BoxGeometry(b.w+.05,.065,b.d+.05),mat(0xf4f0e5));cap.position.set(b.x,b.h+.015,b.z);scene.add(cap);}
addFurryWalls(scene,blocks);const testBlocks=[...blocks],testObstacles=[...obstacleMeshes],testVisuals=scene.children.filter(o=>o!==ground&&o!==grid&&!o.isLight);
function label(text,x,y,z){const c=document.createElement('canvas');c.width=512;c.height=96;const cx=c.getContext('2d');cx.fillStyle='#47554e';cx.font='500 30px system-ui';cx.textAlign='center';cx.fillText(text,256,58);const s=new T.Sprite(new T.SpriteMaterial({map:new T.CanvasTexture(c),transparent:true,depthWrite:false}));s.position.set(x,y,z);s.scale.set(6,1.125,1);scene.add(s);}

// Distant soft shapes keep the practice space readable.
const sphere=new T.SphereGeometry(1,24,16);
for(let i=0;i<28;i++){const a=i*2.399,r=320+(i%5)*15;const m=new T.Mesh(sphere,mat(i%2?0xb6c8b4:0xccd6bf));m.position.set(Math.cos(a)*r,-1,Math.sin(a)*r);m.scale.set(4+i%3,3+i%4,4);scene.add(m);}

const resourceNodes=addResources(scene,blocks,obstacleMeshes),materials={wood:0,stone:0,iron:0,coal:0};
const plush=new T.MeshStandardMaterial({color:0xf5cbb7,roughness:.72});
const white=new T.MeshStandardMaterial({color:0xfffaf4,roughness:.5});
const dark=new T.MeshStandardMaterial({color:0x303040,roughness:.25});
const avatar=new T.Group(),body=new T.Group();avatar.add(body);scene.add(avatar);
function ball(parent,material,x,y,z,sx,sy,sz){const m=new T.Mesh(sphere,material);m.position.set(x,y,z);m.scale.set(sx,sy,sz);m.castShadow=true;parent.add(m);return m;}
ball(body,plush,0,.55,0,.55,.55,.55);
const feet=[-1,1].map(side=>{const leg=new T.Group();leg.position.set(side*.24,.13,0);body.add(leg);ball(leg,plush,0,0,.07,.17,.15,.21);return leg;});
const eyes=[];
for(const side of [-1,1]){
 const eye=new T.Group();eye.position.set(side*.19,.65,.475);body.add(eye);
 ball(eye,white,0,0,0,.145,.177,.07);
 const pupil=ball(eye,dark,0,0,.061,.087,.111,.035);
 ball(pupil,white,-.3,.36,.87,.22,.2,.24);
 ball(pupil,white,.3,-.28,.94,.09,.08,.15);

 const eyeInverse={value:new T.Matrix4()},lidCutoff={value:.19};
 const eyeParts=[];
 eye.traverse(part=>{if(!part.isMesh)return;eyeParts.push(part);part.castShadow=false;part.material=part.material.clone();
 part.material.onBeforeCompile=shader=>{
  shader.uniforms.eyeInverse=eyeInverse;shader.uniforms.lidCutoff=lidCutoff;
  shader.vertexShader='uniform mat4 eyeInverse; varying float eyeHeight;\n'+shader.vertexShader.replace('#include <begin_vertex>','#include <begin_vertex>\neyeHeight=(eyeInverse*modelMatrix*vec4(position,1.0)).y;');
  shader.fragmentShader='uniform float lidCutoff; varying float eyeHeight;\n'+shader.fragmentShader.replace('#include <clipping_planes_fragment>','#include <clipping_planes_fragment>\nif(eyeHeight>lidCutoff) discard;');
 };part.material.customProgramCacheKey=()=> 'eyelid-clip-v4';});
 const lidPositions=new Float32Array(17*17*3),lidIndices=[];
 for(let row=0;row<16;row++)for(let col=0;col<16;col++){const a=row*17+col;lidIndices.push(a,a+1,a+17,a+1,a+18,a+17);}
 const lidGeometry=new T.BufferGeometry();lidGeometry.setAttribute('position',new T.BufferAttribute(lidPositions,3).setUsage(T.DynamicDrawUsage));lidGeometry.setIndex(lidIndices);
 const lid=new T.Mesh(lidGeometry,plush);lid.frustumCulled=false;lid.visible=false;eye.add(lid);
 const lashes=[];
 eyes.push({eye,pupil,lid,lidGeometry,lidPositions,lashes,side,eyeInverse,lidCutoff,eyeParts});
}

const lashStyles={large:{count:3,length:.225,curve:.06},curled:{count:3,length:.25,curve:.15},fan:{count:5,length:.205,curve:.09},short:{count:3,length:.105,curve:.025},none:{count:0,length:0,curve:0}};
function setLashStyle(name){
 const style=lashStyles[name]||lashStyles.large;
 for(const e of eyes){
  for(const lash of e.lashes){e.eye.remove(lash.pivot);lash.pivot.traverse(m=>{if(m.isMesh)m.geometry.dispose();});}e.lashes.length=0;
  for(let j=0;j<style.count;j++){
   const fan=(j/(style.count-1)-.5)*1.4,pivot=new T.Group();e.eye.add(pivot);
   const length=style.length*(1-Math.abs(fan)*.15);
   const curve=new T.QuadraticBezierCurve3(new T.Vector3(),new T.Vector3(fan*.065,length*.55,-style.curve*.15),new T.Vector3(fan*.13,length,style.curve));
   pivot.add(new T.Mesh(new T.TubeGeometry(curve,12,name==='short'?.012:.015,6,false),dark));e.lashes.push({pivot,fan});
  }
 }
 try{localStorage.setItem('pompon-lashes',name);}catch{}
}
let initialLashes='large';try{initialLashes=localStorage.getItem('pompon-lashes')||'large';}catch{}
if(!lashStyles[initialLashes])initialLashes='large';setLashStyle(initialLashes);
const hair=createHair(body);const arms=[];
for(const side of [1,-1]){
 const mesh=ball(body,plush,0,0,0,.105,.3,.105),hand=ball(body,plush,side*.85,.28,0,.145,.16,.145);
 const forearm=ball(body,plush,0,0,0,.095,.2,.095);forearm.visible=false;
 arms.push({side,mesh,hand,forearm,pos:new T.Vector3(side*.85,.28,0),vel:new T.Vector3(),anchor:new T.Vector3(side*.46,.35,-.08)});
}
const vitals=createVitals(),npc=createNPC(scene);
let p=createPlayer(),yaw=0,pitch=DEFAULT_CAMERA_PITCH,distance=DEFAULT_CAMERA_DISTANCE,heading=0,time=0,previous=performance.now(),accumulator=0;
let firePulse=false,triggerLeft=false,triggerRight=false,aimX=innerWidth/2,aimY=innerHeight/2;
let softness=0,softVelocity=0,gazeX=0,gazeY=0,gazeTX=0,gazeTY=0,nextGaze=1,nextBlink=2,blinkStart=-10;
const previousPose={x:p.x,y:p.y,z:p.z,softness:0};
const mouseSensitivity=createSensitivity();const cameraInput=createCameraInput({precise:()=>mouseSensitivity.mode==='cs'});let boomDistance=DEFAULT_CAMERA_DISTANCE;
const input=createInput(),keys=input.held,focus=new T.Vector3(0,.7,5),desired=new T.Vector3(),ray=new T.Raycaster();
const cameraButton=document.getElementById('camera-mode');let cameraWanted=false,cameraRestoreUntil=0,autoPause=localStorage.getItem('pompon-auto-pause')!=='false';let chat=null,supply=null,placementClick=false;let orbitHeld=false;let mouseMode=false,touchDrag=false,rightDrag=false,px=0,py=0;
function clearInput(){cameraInput.reset();orbitHeld=false;firePulse=triggerLeft=triggerRight=false;input.clear();p.buffer=0;p.vx=0;p.vz=0;touchDrag=false;rightDrag=false;}
function down(code,repeat=false){if(input.down(code,repeat)&&code==='Space')p.buffer=.12;}
function up(code){const wasHeld=input.up(code);if(wasHeld&&code==='Space'&&p.vy>7.2)p.vy*=.55;}
function updateCameraButton(){cameraButton.textContent=mouseMode?'Liberar cursor · C':cameraWanted?'Cámara lista · clic para volver':'Activar cámara · C';cameraButton.setAttribute('aria-pressed',String(mouseMode));document.body.classList.toggle('camera-locked',mouseMode);}
function clearActions(){orbitHeld=false;firePulse=triggerLeft=triggerRight=false;touchDrag=rightDrag=false;}
function disableCamera(temporary=false){if(temporary)cameraRestoreUntil=performance.now()+500;if(!temporary)cameraWanted=false;mouseMode=false;if(document.pointerLockElement)document.exitPointerLock();clearActions();updateCameraButton();}
function cameraFailure(error){
 mouseMode=false;clearActions();updateCameraButton();
 const notice=document.getElementById('camera-notice');notice.hidden=false;
 notice.querySelector('p').textContent=globalThis.chrome?.webview?'Hacé clic dentro de la ventana y volvé a activar la cámara con C.':'No se pudo capturar el mouse. Hacé clic dentro del juego y volvé a activar la cámara con C.';notice.querySelector('a').hidden=true;
 notice.dataset.reason=error?.message||'Pointer lock denied';
}
async function enableCamera(){
 cameraWanted=true;
 clearActions();document.getElementById('camera-notice').hidden=true;
 try {if(!renderer.domElement.requestPointerLock)throw Error('Pointer lock unavailable');await captureRawMouse(renderer.domElement);}
 catch(error){cameraFailure(error);}
}
function toggleCamera(){if(cameraWanted)disableCamera();else enableCamera();}
const movementCodes=['KeyW','KeyA','KeyS','KeyD','ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Space','ShiftLeft','ShiftRight','ControlLeft','KeyZ','KeyV'];
function gameKeyDown(e){if(document.body.classList.contains('training-active')){training.action(e.code,true);return;}
 if(supply?.open){if(e.code==='Escape')supply.close();return;}if(chat?.open){if(e.code==='Escape')chat.close();return;}if(e.code==='Enter'&&!e.repeat&&!menu.open&&!inventory.open&&!building.open){chat.show();return;}
 if(e.code==='Escape'&&progression?.open){progression.close();return;}if(frontEnd?.home&&!menu.open)return;if(e.code==='Escape'&&document.querySelector('#arena-lobby[open]')){e.preventDefault();document.getElementById('arena-lobby').close();return;}if(e.code==='Escape'){e.preventDefault();if(!e.repeat){if(building.placing){building.key(e);return;}if(inventory.open){inventory.close();return;}if(building.open){building.close();return;}if(menu.open)closeMenu();else openMenu();}return;}
 if(menu.open)return;if(globalThis.pomponArena&&['KeyB','KeyJ','KeyQ','KeyE','KeyG'].includes(e.code))return;
 if(e.code==='Orbit'){orbitHeld=true;return;}
 if(e.code==='Mouse0'||e.code==='Mouse2'){const button=e.code==='Mouse0'?0:2;if(building.click(button)||utilities.click(button))return;if(!menu.open&&!inventory.open&&!building.open&&farm?.click(button))return;if(inventory.open||building.open)return;if(button===0)triggerLeft=true;else triggerRight=true;return;}
 if(e.code==='KeyG'&&!building.open&&farm?.key(e))return;if(e.code==='KeyE'&&!e.repeat&&supply?.near()){supply.show();return;}if(chests.key(e)||building.key(e)||inventory.key(e)){e.preventDefault();return;}if(inventory.open||building.open)return;
 if(e.code==='WheelUp'||e.code==='WheelDown'){distance=T.MathUtils.clamp(distance+(e.code==='WheelUp'?-.4:.4),4.5,8);return;}
 if(movementCodes.includes(e.code)){document.activeElement?.blur();e.preventDefault();down(e.code,e.repeat);}
 if(!e.repeat&&e.code==='KeyR'&&!inventory.packSelected())gun.reload(inventory.both,kind=>inventory.consumeMagazine(kind));
 if(!e.repeat&&e.code==='KeyC')toggleCamera();
 if(!e.repeat&&e.code==='KeyH'&&inventory.hands().some(k=>['flash','smoke','c4'].includes(k))){utilities.cancel();inventory.swapHands();return;}
 if(!e.repeat&&e.code==='KeyH'&&transferTime===0&&(firearmHand()>=0||inventory.heavy||inventory.heldTool())){transferTime=.38;transferSwapped=false;triggerLeft=triggerRight=false;}
 if(!e.repeat&&e.code==='Backspace')reset();
}
 addEventListener('blur',()=>{if(document.body.classList.contains('training-active'))return;clearInput();disableCamera(true);if(autoPause&&!menu.open&&!inventory.open&&!building.open)openMenu();});
addEventListener('focus',clearInput);addEventListener('pagehide',clearInput);
// Reconcile input at every focus boundary, including moving between the game and app chrome.
document.addEventListener('visibilitychange',()=>{if(document.body.classList.contains('training-active')){if(document.hidden)training.action('Escape',true);return;}clearInput();if(document.hidden){disableCamera(true);if(autoPause&&!menu.open&&!inventory.open&&!building.open)openMenu();}});
document.addEventListener('pointerlockchange',()=>{if(training?.active)return;const wasLocked=mouseMode;cameraInput.reset(2);clearActions();mouseMode=document.pointerLockElement===renderer.domElement;updateCameraButton();if(mouseMode)document.getElementById('camera-notice').hidden=true;else if(wasLocked&&performance.now()>cameraRestoreUntil&&!menu.open&&!inventory.open&&!building.open&&autoPause)openMenu();});
document.addEventListener('pointerlockerror',()=>cameraFailure());
document.addEventListener('focusin',e=>{if(e.target instanceof HTMLButtonElement&&e.target.closest('dialog'))clearInput();});
document.addEventListener('mousemove',e=>{if(!mouseMode){aimX=e.clientX;aimY=e.clientY;}});
renderer.domElement.addEventListener('pointerleave',()=>{if(!document.pointerLockElement&&!rightDrag&&!touchDrag)clearActions();});
renderer.domElement.addEventListener('contextmenu',e=>e.preventDefault());
renderer.domElement.addEventListener('pointerdown',e=>{if(training.active)return;if(gun.kind==='sniper'&&firearmHand()>=0||menu.open||inventory.open||building.open||mouseMode||(inventory.handOf('gun')===1||inventory.handOf('sword')===1))return;if(e.pointerType==='touch')touchDrag=true;else if(controls.button(e)===2){rightDrag=true;e.preventDefault();}else return;px=e.clientX;py=e.clientY;renderer.domElement.setPointerCapture(e.pointerId);});
document.addEventListener(cameraMotionEvent(),e=>{if(ignoreDesktopMotion(e))return;if(training.active)return;if(menu.open||inventory.open||building.open||chat?.open||supply?.open)return;if(mouseMode&&document.pointerLockElement===renderer.domElement){cameraInput.push(e.movementX,e.movementY,mouseSensitivity.radians()*(gun.kind==='sniper'&&triggerRight?preferences.sniperSensitivity:1));return;}if(orbitHeld){cameraInput.push(e.movementX,e.movementY,.003);return;}if(!touchDrag&&!rightDrag)return;if(rightDrag&&!controls.rightPressed(e.buttons)){rightDrag=false;cameraInput.reset();return;}cameraInput.push(e.clientX-px,e.clientY-py,mouseSensitivity.radians());px=e.clientX;py=e.clientY;});
renderer.domElement.addEventListener('pointerup',e=>{touchDrag=false;if(controls.button(e)===2)rightDrag=false;if(renderer.domElement.hasPointerCapture(e.pointerId))renderer.domElement.releasePointerCapture(e.pointerId);});renderer.domElement.addEventListener('lostpointercapture',()=>{rightDrag=false;touchDrag=false;});renderer.domElement.addEventListener('pointercancel',clearInput);

cameraButton.onclick=()=>{toggleCamera();cameraButton.blur();};
document.querySelectorAll('[data-key]').forEach(b=>{b.addEventListener('pointerdown',e=>{e.preventDefault();b.setPointerCapture(e.pointerId);down(b.dataset.key);});for(const name of ['pointerup','pointercancel','lostpointercapture'])b.addEventListener(name,()=>up(b.dataset.key));});
function reset(){clearInput();p=createPlayer();Object.assign(vitals,createVitals());npc.reset();focus.set(p.x,p.y+.7,p.z);yaw=0;heading=0;softness=softVelocity=0;Object.assign(previousPose,{x:p.x,y:p.y,z:p.z,softness:0});accumulator=0;for(const a of arms){a.pos.set(a.side*.85,.28,0);a.vel.set(0,0,0);}document.activeElement?.blur();}document.getElementById('reset').onclick=reset;


function resumeCamera(){cameraRestoreUntil=performance.now()+500;queueMicrotask(()=>{if(!frontEnd?.home&&cameraWanted&&!document.hidden&&!menu.open&&!inventory.open&&!building.open&&!chat?.open&&!supply?.open)enableCamera();});}
const menu=document.getElementById('pause-menu'),lashSelect=document.getElementById('lash-style');
setupColorWheel(hex=>plush.color.set(hex));
let savedCamera=null;
function openMenu(){if(document.body.classList.contains('training-active'))return;if(frontEnd?.home&&!frontEnd.settings)return;if(menu.open||inventory.open||building.open)return;disableCamera(true);document.getElementById('camera-notice').hidden=true;accumulator=0;Object.assign(previousPose,{x:p.x,y:p.y,z:p.z,softness});savedCamera=null;menu.showModal();}
function closeMenu(){if(!menu.open)return;menu.close();if(savedCamera){({yaw,pitch,distance}=savedCamera);savedCamera=null;}clearInput();previous=performance.now();accumulator=0;dispatchEvent(new Event('pompon-menu-closed'));if(!frontEnd?.home)resumeCamera();}
menu.addEventListener('cancel',e=>{e.preventDefault();closeMenu();});

lashSelect.value=initialLashes;lashSelect.onchange=()=>setLashStyle(lashSelect.value);
document.getElementById('menu-open').onclick=openMenu;
document.getElementById('resume').onclick=closeMenu;
document.getElementById('resume-camera').onclick=()=>{closeMenu();if(!frontEnd?.home)enableCamera();};
document.getElementById('menu-reset').onclick=()=>{closeMenu();reset();};
document.getElementById('blink-preview').onclick=()=>{blinkStart=time;nextBlink=time+3;};
const handAnchors=[new T.Object3D(),new T.Object3D()];handAnchors.forEach((a,i)=>{a.position.set(i===0?.77:-.77,.53,.22);body.add(a);});
const defaultSword=createSword(scene,blocks,avatar),smg=createGun(scene,blocks,avatar),rifle=createGun(scene,blocks,avatar,true),sniper=createGun(scene,blocks,avatar,'sniper');let sword=defaultSword,gun=smg;
const firearmHand=()=>inventory.heldFirearm()?.hand??-1;
const inventory=setupInventory({sword,gun:smg,rifle,sniper,scene,carrier:avatar,blocks,stock:materials,onPlace:kind=>building.begin(kind),getPlayer:()=>p,getHeading:()=>heading,getHand:i=>{scene.updateMatrixWorld(true);return handAnchors[i??1].getWorldPosition(new T.Vector3());},pause:()=>{if(menu.open)closeMenu();disableCamera(true);clearInput();accumulator=0;Object.assign(previousPose,{x:p.x,y:p.y,z:p.z,softness});},resume:resumeCamera,isPaused:()=>menu.open});
const sight=setupCrosshair(),aimRay=new T.Raycaster(),aimTarget=new T.Vector3();
const ammoHUD=document.getElementById('ammo-hud'),ammoDisplay=document.getElementById('ammo-display');
let ammoStyle='panel';try{ammoStyle=localStorage.getItem('pompon-ammo-display')==='hologram'?'hologram':'panel';}catch{}ammoDisplay.value=ammoStyle;
ammoDisplay.addEventListener('change',()=>{ammoStyle=ammoDisplay.value;try{localStorage.setItem('pompon-ammo-display',ammoStyle);}catch{}});
renderer.domElement.addEventListener('mousedown',e=>{if(training.active)return;if(placementClick||chat?.open||supply?.open||menu.open||inventory.open||building.open||building.placing)return;if(utilities.click(controls.button(e))||farm?.click(controls.button(e)))return;if(controls.button(e)===0)triggerLeft=true;if(controls.button(e)===2)triggerRight=true;if(firearmHand()>=0&&controls.button(e)===actionButton(gun.twoHanded,firearmHand()))firePulse=true;});
window.addEventListener('pointerup',e=>{if(!training.active)utilities.release(controls.button(e));placementClick=false;},true);
window.addEventListener('mouseup',e=>{utilities.release(controls.button(e));placementClick=false;if(controls.button(e)===0)triggerLeft=false;if(controls.button(e)===2)triggerRight=false;},true);
const controls=setupControls((code,pressed,event)=>{if(code==='KeyY'&&pressed&&event.repeat)return;if(progression?.action(code,pressed)){event.preventDefault();return;}if(code==='KeyU'){voice?.key(pressed);return;}if(pressed)gameKeyDown({code,repeat:!!event.repeat,preventDefault:()=>event.preventDefault()});else{if(document.body.classList.contains('training-active')){training.action(code,false);return;}if(code==='Mouse2')utilities.release(2);up(code);if(code==='Orbit')orbitHeld=false;if(code==='Mouse0')triggerLeft=false;if(code==='Mouse2')triggerRight=false;}});
const building=setupBuilding({scene,blocks,obstacles:obstacleMeshes,stock:materials,inventory,getPlayer:()=>p,getHeading:()=>yaw+Math.PI,pause:()=>{if(menu.open)closeMenu();if(inventory.open)inventory.close();disableCamera(true);clearInput();},resume:resumeCamera});
 document.getElementById('recipe-close').onclick=()=>building.close();document.getElementById('book-open').onclick=()=>building.key({code:'KeyB',repeat:false});
 renderer.domElement.addEventListener('pointerdown',e=>{if(training.active)return;if(!building.placing&&utilities.click(controls.button(e))){placementClick=true;clearActions();return;}if(building.click(controls.button(e))){placementClick=true;clearActions();e.preventDefault();e.stopImmediatePropagation();}},true);
 const status=document.getElementById('status');let statusText='';
const pauseToggle=document.getElementById('auto-pause');pauseToggle.checked=autoPause;pauseToggle.onchange=()=>{autoPause=pauseToggle.checked;localStorage.setItem('pompon-auto-pause',String(autoPause));};
renderer.domElement.addEventListener('pointerdown',()=>{if(cameraWanted&&!mouseMode&&!menu.open&&!inventory.open&&!building.open)enableCamera();});
const creativeToggle=document.getElementById('creative-mode');try{creativeToggle.checked=localStorage.getItem('pompon-creative')==='true';}catch{}creativeToggle.addEventListener('change',()=>{try{localStorage.setItem('pompon-creative',String(creativeToggle.checked));}catch{}document.getElementById('creative-badge').hidden=!creativeToggle.checked;});document.getElementById('creative-badge').hidden=!creativeToggle.checked;
let progression=null;let voice=null;let farm=null,wasDead=false,localRespawn=0;const online=setupMultiplayer({scene,camera,inventory,building,blocks,getProfile:()=>frontEnd?.profile,getProgress:()=>playerProgress(),onSession:mode=>configureWorld(mode||'survival'),onResume:data=>restorePlayer(data),onFarm:data=>farm?.restoreNetwork(data),onChat:message=>chat?.receive(message),onJoin:pose=>{if(pose){p.x=pose.x;p.y=pose.y;p.z=pose.z;Object.assign(previousPose,{x:p.x,y:p.y,z:p.z});}},getPose:()=>({x:avatar.position.x,y:avatar.position.y,z:avatar.position.z,heading,hair:preferences.hair,hairColor:preferences.hairColor,vx:p.vx,vz:p.vz,leashCount:inventory.kitCount('leash'),ground:p.ground,vy:p.vy,color:plush.color.getHex(),lashes:lashSelect.value,blink:blinkClosure(time-blinkStart),gaze:[gazeX,gazeY],bodyScale:body.scale.toArray(),bodyRotation:body.quaternion.toArray(),feet:feet.map(f=>({position:f.position.toArray(),quaternion:f.quaternion.toArray()})),armPose:arms.map(a=>({position:a.mesh.getWorldPosition(new T.Vector3()).sub(avatar.position).applyAxisAngle(new T.Vector3(0,1,0),-heading).toArray(),quaternion:new T.Quaternion().setFromAxisAngle(new T.Vector3(0,1,0),-heading).multiply(a.mesh.getWorldQuaternion(new T.Quaternion())).toArray(),scale:a.mesh.getWorldScale(new T.Vector3()).toArray()})),backpack:inventory.backpack,stored:inventory.storedPose(),hands:inventory.hands(),gear:[0,1].map(i=>inventory.heldItem(i)?.pose?.()||null),limbs:arms.map(a=>a.hand.getWorldPosition(new T.Vector3()).sub(avatar.position).applyAxisAngle(new T.Vector3(0,1,0),-heading).toArray())}),applyNPC:health=>{npc.state.health=health;},applyHealth:(health,respawn)=>{if(Number.isFinite(health)){vitals.health=health;if(health<=0&&!wasDead&&!globalThis.pomponArena)inventory.dropAll();wasDead=health<=0;}if(respawn){p=createPlayer();Object.assign(previousPose,{x:p.x,y:p.y,z:p.z});clearInput();}},weaponModel:kind=>kind==='gun'?smg.visualClone():kind==='rifle'?rifle.visualClone():kind==='sniper'?sniper.visualClone():kind==='sword'?defaultSword.visualClone():kind?itemModel(kind):null,pause:openMenu});
building.setNetwork((path,data)=>online.request(path,data));chat=setupChat({camera,getLocal:()=>avatar.position.clone(),getRemote:id=>online.position(id),send:text=>online.chat(text),pause:()=>{disableCamera(true);clearInput();},resume:resumeCamera});
supply=setupSupply({scene,blocks,inventory,materials,getPlayer:()=>p,model:kind=>kind==='rifle'?rifle.visualClone():kind==='sniper'?sniper.visualClone():smg.visualClone(),pause:()=>{disableCamera(true);clearInput();},resume:resumeCamera});
const scope=document.createElement('div');scope.id='sniper-scope';scope.hidden=true;document.body.append(scope);
const backpackVisual=itemModel('backpack');backpackVisual.position.set(0,.28,-.63);backpackVisual.rotation.y=Math.PI;backpackVisual.scale.setScalar(1.05);avatar.add(backpackVisual);
farm=setupFarm({scene,camera,blocks,trees:resourceNodes.filter(n=>n.userData.resourceType==='wood').map(n=>({x:n.position.x,z:n.position.z})),inventory,vitals,getPlayer:()=>p,getHeading:()=>heading,getDigDirection:()=>camera.getWorldDirection(new T.Vector3()),getHand:()=>handAnchors[Math.max(0,inventory.hands().indexOf('leash'))].getWorldPosition(new T.Vector3()),online,isBlocked:()=>menu.open||inventory.open||building.open||chat.open||supply.open});
const chests=setupChests({blocks,inventory,online,pause:()=>{disableCamera(true);clearInput();},resume:resumeCamera,getPlayer:()=>p});
const utilities=setupUtilities({scene,camera,blocks,inventory,online,getPlayer:()=>p,getState:()=>farm.snapshot(),getDirection:()=>aimRay.ray.at(40,new T.Vector3()).sub(new T.Vector3(p.x,p.y+1.05,p.z)).normalize(),isPaused:()=>vitals.health<=0||menu.open||inventory.open||building.open||chat.open||supply.open});
const water=setupWater({scene,getState:()=>farm.snapshot(),getPlayer:()=>p,vitals,online,terrainGeo});
progression=setupProgression({online,available:()=>!!frontEnd&&!frontEnd.home&&!training.active,releaseCamera:()=>{disableCamera(true);clearInput();}});const sounds=setupSound(()=>p);const ui=setupInterface({getPose:()=>online.localPose(),inventory,closeMenu,leave:()=>frontEnd?.goHome().catch(()=>{})});mouseSensitivity.mount();
const sessionRoster=setupPlayers({panel:ui.friends,online});
const arena=setupArena({scene,avatar,blocks,obstacles:obstacleMeshes,inventory,online,getPlayer:()=>p,panel:ui.arena,closeMenu,onSpawn:spawn=>{heading=spawn.heading;yaw=heading-Math.PI;pitch=.3;Object.assign(previousPose,{x:p.x,y:p.y,z:p.z});}});
voice=setupVoice({panel:ui.audio,online,getPlayer:()=>p});
const combatTargets={hit(origin,direction,max=70,radius=0){const a=globalThis.pomponArena?null:npc.hit(origin,direction,max,radius),b=online.hit(origin,direction,max,radius);if(a){const original=a.apply;a.apply=(amount,weapon)=>{original(amount);online.npcDamage(amount,weapon);};}const c=globalThis.pomponArena?null:farm?.hit(origin,direction,max,radius);return [a,b,c].filter(Boolean).sort((x,y)=>x.distance-y.distance)[0]||null;}};

const spectator=setupSpectator({online,camera,avatar,blocks,health:()=>vitals.health,inventory});
const practiceInventory=inventory.serialize(),background=menuBackground(()=>rifle.visualClone());
function configureWorld(mode){const practice=mode==='test';document.getElementById('host-game').hidden=true;globalThis.pomponWorldMode=mode;for(const o of testVisuals)o.visible=practice;for(const b of testBlocks){const i=blocks.indexOf(b);if(!practice&&i>=0)blocks.splice(i,1);else if(practice&&i<0)blocks.push(b);}for(const o of testObstacles){const i=obstacleMeshes.indexOf(o);if(!practice&&i>=0)obstacleMeshes.splice(i,1);else if(practice&&i<0)obstacleMeshes.push(o);}npc.setEnabled(practice);supply.setEnabled(practice);const creative=document.getElementById('creative-mode');creative.checked=practice;creative.disabled=!practice;creative.dispatchEvent(new Event('change'));}
function playerProgress(){return {inventory:inventory.serialize(true),materials:{...materials},vitals:{...vitals},hunger:farm.hunger,pose:{x:p.x,y:p.y,z:p.z,heading,yaw,pitch},appearance:{color:plush.color.getHex(),lashes:lashSelect.value,hair:preferences.hair,hairColor:preferences.hairColor}};}
function restorePlayer(data){if(!data)return;progression.restore(data.economy);inventory.restore(data.inventory||{});for(const key of Object.keys(materials))delete materials[key];Object.assign(materials,{wood:0,stone:0,iron:0,coal:0},data.materials||{});Object.assign(vitals,createVitals(),data.vitals||{});farm.setHunger(data.hunger??100);if(data.pose){Object.assign(p,data.pose,{vx:0,vy:0,vz:0});heading=data.pose.heading||0;yaw=data.pose.yaw||0;pitch=data.pose.pitch??.4;}if(data.appearance){plush.color.setHex(data.appearance.color);lashSelect.value=data.appearance.lashes||'large';lashSelect.dispatchEvent(new Event('change'));preferences.hair=data.appearance.hair||'none';preferences.hairColor=data.appearance.hairColor||'#593a29';}Object.assign(previousPose,{x:p.x,y:p.y,z:p.z});}
function worldSnapshot(){return {economy:progression.serialize(),version:1,...playerProgress(),inventory:inventory.serialize(),farm:structuredClone(farm.snapshot()),buildings:building.snapshot()};}
const training=setupTraining({canvas:renderer.domElement,crosshair:sight,button:e=>controls.button(e),getDistance:()=>distance,sensitivity:()=>mouseSensitivity.radians(),getAppearance:()=>({color:plush.color.getHex(),lashes:document.getElementById('lash-style').value,hair:preferences.hair,hairColor:preferences.hairColor}),onExit:()=>frontEnd.goHome()});
frontEnd=setupMainMenu({online,capture:worldSnapshot,openSettings:()=>{openMenu();ui.show('settings');},onStart:async(mode,world,profile)=>{if(mode==='training'){closeMenu();inventory.close();building.close();disableCamera();clearInput();training.start(world.id);return;}closeMenu();inventory.close();building.close();clearInput();reset();progression.restore();building.restore([]);configureWorld(mode==='test'?'test':'survival');inventory.restore(mode==='test'?practiceInventory:{});for(const key of Object.keys(materials))materials[key]=0;farm.load(mode==='single'||mode==='test'?world.data?.farm:null);farm.setHunger(100);if(mode==='single'||mode==='test'){if(world.data){restorePlayer(world.data);building.restore(world.data.buildings||[]);}}else if(mode==='duel'){await online.hostWorld({mode:'duel',maxPlayers:world.format==='2v2'?4:2});await online.request('/api/arena',{action:'create',mode:world.format});}else if(mode==='cloud'){await online.joinCloud(world.id);}else if(mode==='multi'){await online.hostWorld({worldId:world.id,name:world.name,maxPlayers:world.maxPlayers});openMenu();ui.show('friends');}else await online.join(world.id);Object.assign(previousPose,{x:p.x,y:p.y,z:p.z});},onStop:async()=>{training.stop();farm.release();if(online.active)await online.leave();disableCamera();clearInput();closeMenu();inventory.close();building.close();}});
document.getElementById('leave-game').onclick=()=>frontEnd.goHome().catch(()=>{});
const saveWorldButton=document.createElement('button');saveWorldButton.textContent='Guardar partida ahora';saveWorldButton.onclick=()=>frontEnd.save().catch(()=>{});ui.home.append(saveWorldButton);const trainingButton=document.createElement('button');trainingButton.textContent='Entrenamiento de puntería';trainingButton.onclick=()=>{closeMenu();frontEnd.training().catch(()=>{});};ui.home.append(trainingButton);

const display=setupDisplay(renderer,scene,camera,sun),punches=[{timer:0,hit:false},{timer:0,hit:false}];
let swordStructureCooldown=0,holoX=null,holoY=null;let transferTime=0,transferSwapped=false;let gaitPhase=0;let lean=0;let toolCooldown=0,toolSwing=0,toolHit=false;let punchCooldown=0,nextPunch=0,swordReady=true,swordCooldown=0;
let shadowAt=-Infinity;renderer.shadowMap.autoUpdate=false;
function frame(now){if(training.active){utilities.hide();const dt=Math.max(0,Math.min(.05,(now-previous)/1000));previous=now;accumulator=0;training.render(renderer,dt);requestAnimationFrame(frame);return;}if(frontEnd?.home){utilities.hide();const dt=Math.max(0,Math.min(.05,(now-previous)/1000));previous=now;accumulator=0;if(online.active){online.update(dt);arena.update();frontEnd.update(dt);}background.render(renderer,now/1000,dt);requestAnimationFrame(frame);return;}
 display.update(now-previous,online.networkStats);
 gun=inventory.heldFirearm()?.item||smg;sword=inventory.heldWeapon('sword')||defaultSword;
 if(!document.hasFocus()||document.hidden)clearInput();
 globalThis.pomponOnlineActive=online.active;const delta=cameraInput.consume();yaw-=delta.x;pitch=T.MathUtils.clamp(pitch+delta.y,-1.48,1.48);const dt=Math.max(0,Math.min((now-previous)/1000,.05));previous=now;time+=dt;if(!online.active){if(vitals.health<=0&&!wasDead){progression.die();wasDead=true;localRespawn=3;inventory.dropAll();}if(wasDead){localRespawn-=dt;if(localRespawn<=0){reset();wasDead=false;}}document.getElementById('death-notice').hidden=!wasDead;}const inputBlocked=menu.open||inventory.open||building.open||chat.open||supply.open||progression.open||!!document.querySelector('#arena-lobby[open]')||vitals.health<=0;accumulator+=dt;if(inputBlocked){keys.clear();p.buffer=0;}
 const side=(keys.has('KeyD')||keys.has('ArrowRight')?1:0)-(keys.has('KeyA')||keys.has('ArrowLeft')?1:0),forward=(keys.has('KeyW')||keys.has('ArrowUp')?1:0)-(keys.has('KeyS')||keys.has('ArrowDown')?1:0);
 const ix=side*Math.cos(yaw)-forward*Math.sin(yaw),iz=-side*Math.sin(yaw)-forward*Math.cos(yaw);

 while(accumulator>=1/120){
  Object.assign(previousPose,{x:p.x,y:p.y,z:p.z,softness});
  p.canClimb=!inputBlocked;p.climbInput=forward;p.climbSideInput=side;p.hurtSpheres=npc.spheres();p.heavy=inventory.heavy;p.mobility=inventory.mobility*sprint(vitals,!inputBlocked&&!keys.has('ControlLeft')&&!p.inWater&&!p.climbing&&(keys.has('ShiftLeft')||keys.has('ShiftRight')),!!(side||forward)&&Math.hypot(p.vx,p.vz)>.15,1/120,progression.levels);
  const oldVX=p.vx,oldVZ=p.vz;p.swimUp=keys.has("Space");p.swimDive=keys.has("ControlLeft");p.sneaking=keys.has("ControlLeft");step(p,ix,iz,1/120);if(!globalThis.pomponArena)npc.resolve(p,arms.map(a=>({x:a.pos.x*Math.cos(heading)+a.pos.z*Math.sin(heading),y:a.pos.y,z:-a.pos.x*Math.sin(heading)+a.pos.z*Math.cos(heading),r:.14})));
  online.resolve(p);farm?.resolve(p);
  if(p.impact>0)softVelocity-=Math.min(3.2,p.impact*.12);
  const target=p.ground?0:Math.min(.12,Math.abs(p.vy)*.005);
  [softness,softVelocity]=spring(softness,softVelocity,target,1/120,150,12);
  softness=T.MathUtils.clamp(softness,-.25,.17);
  const ax=(p.vx-oldVX)*120,az=(p.vz-oldVZ)*120;
  const localAX=ax*Math.cos(heading)-az*Math.sin(heading),localAZ=ax*Math.sin(heading)+az*Math.cos(heading);
  for(const a of arms){
   const run=Math.min(1,Math.hypot(p.vx,p.vz)/14.4);
   const tx=a.side*(.82+(p.ground?.03:.12))-T.MathUtils.clamp(localAX*.0018,-.17,.17);
   const ty=p.ground?(inventory.heavy&&a.side===1?.46:.31):.55+T.MathUtils.clamp(-p.vy*.037,-.45,.72);
   const tz=-run*.22-T.MathUtils.clamp(localAZ*.002,-.2,.2);
   for(const [axis,target] of [['x',tx],['y',ty],['z',tz]])[a.pos[axis],a.vel[axis]]=spring(a.pos[axis],a.vel[axis],target,1/120,75,9);
   const delta=a.pos.clone().sub(a.anchor);if(delta.length()>1.03){delta.setLength(1.03);a.pos.copy(a.anchor).add(delta);a.vel.multiplyScalar(.8);}
   a.pos.y=Math.max(.14,a.pos.y);
  }
  accumulator-=1/120;
 }
 const speed=Math.hypot(p.vx,p.vz);
 if((mouseMode||triggerLeft||triggerRight)&&!menu.open&&!inventory.open&&!building.open&&(mouseMode||inventory.heavy||firearmHand()>=0)){const wanted=yaw+Math.PI;heading+=Math.atan2(Math.sin(wanted-heading),Math.cos(wanted-heading))*(1-Math.exp(-12*dt));}
 else if(speed>.5){const angle=Math.atan2(p.vx,p.vz),diff=Math.atan2(Math.sin(angle-heading),Math.cos(angle-heading));heading+=diff*(1-Math.exp(-18*dt));}
 const alpha=accumulator/(1/120);
 avatar.position.set(T.MathUtils.lerp(previousPose.x,p.x,alpha),T.MathUtils.lerp(previousPose.y,p.y,alpha),T.MathUtils.lerp(previousPose.z,p.z,alpha));avatar.rotation.y=heading;
 const basePose=avatar.position.clone();const leanTarget=menu.open||inventory.open||building.open?0:(keys.has('KeyV')?1:0)-(keys.has('KeyZ')?1:0);lean=T.MathUtils.damp(lean,leanTarget,12,dt);const leanDirection=new T.Vector3(Math.cos(yaw)*Math.sign(lean),0,-Math.sin(yaw)*Math.sign(lean)),leanOrigin=avatar.position.clone().add(new T.Vector3(0,.85,0)),leanHit=solidHit(leanOrigin,leanDirection,blocks,Math.abs(lean)*.85,.15);const leanAmount=leanHit?Math.max(0,leanHit.distance-.015):Math.abs(lean)*.85;avatar.position.addScaledVector(leanDirection,leanAmount);body.rotation.z=-Math.sign(lean)*leanAmount*.15*Math.cos(heading-yaw);

 // Ground movement stays level; only real landings compress the body.
 body.position.y=0;
gaitPhase+=dt*Math.min(16,4+speed*.85);for(let i=0;i<feet.length;i++){const phase=gaitPhase+i*Math.PI,walking=speed>.4||(p.climbing&&p.climbMoving>.05);feet[i].position.y=.13+(walking?Math.max(0,Math.sin(phase))*.09:0);feet[i].position.z=walking?Math.cos(phase)*.13:0;feet[i].rotation.x=walking?Math.cos(phase)*.3:0;}

 const sy=1+T.MathUtils.lerp(previousPose.softness,softness,alpha),sxz=1/Math.sqrt(sy);body.scale.set(sxz,sy,sxz);
 for(const a of arms){a.forearm.visible=false;const delta=a.pos.clone().sub(a.anchor),length=delta.length();a.mesh.position.copy(a.anchor).addScaledVector(delta,.5);a.mesh.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),delta.normalize());const width=.105/Math.sqrt(Math.max(.7,length/.4));a.mesh.scale.set(width,length/2+.025,width);a.hand.position.copy(a.pos);}
 if(time>nextGaze){gazeTX=(Math.random()-.5)*.075;gazeTY=(Math.random()-.5)*.045;nextGaze=time+1.1+Math.random()*2.2;}
 gazeX=T.MathUtils.damp(gazeX,gazeTX,9,dt);gazeY=T.MathUtils.damp(gazeY,gazeTY,9,dt);

 if(time>nextBlink){blinkStart=time;nextBlink=time+2.3+Math.random()*3;}
 const closure=blinkClosure(time-blinkStart);
 for(const e of eyes){
  e.pupil.position.x=gazeX;e.pupil.position.y=gazeY;
  const lookPitch=(mouseMode||triggerLeft||triggerRight)?T.MathUtils.clamp(pitch*.65,-.85,.85):0;
  e.eye.rotation.x=T.MathUtils.damp(e.eye.rotation.x,lookPitch,10,dt);
  const faceAngle=e.eye.rotation.x;e.eye.position.y=.55+.10*Math.cos(faceAngle)-.475*Math.sin(faceAngle);e.eye.position.z=.10*Math.sin(faceAngle)+.475*Math.cos(faceAngle);
  e.lidCutoff.value=.185*(1-2*closure);
  for(const part of e.eyeParts)part.visible=closure<.999;
  e.lid.visible=closure>.001;
  if(e.lid.visible){
   const cutoff=.185*(1-2*closure);
   for(let row=0;row<=16;row++){
    const y=T.MathUtils.lerp(cutoff,.185,row/16),span=.154*Math.sqrt(Math.max(0,1-(y/.185)**2));
    for(let col=0;col<=16;col++){const x=(col/8-1)*span,j=(row*17+col)*3;e.lidPositions[j]=x;e.lidPositions[j+1]=y;e.lidPositions[j+2]=.012+.075*Math.sqrt(Math.max(0,1-(x/.154)**2-(y/.185)**2));}
   }
   e.lidGeometry.attributes.position.needsUpdate=true;e.lidGeometry.computeVertexNormals();
  }
  for(const lash of e.lashes){
   const x=lash.fan*.142;
   const upper=.177*Math.sqrt(Math.max(0,1-(x/.145)**2))*.97;
   const y=T.MathUtils.lerp(upper,-.153,closure);
   const depth=.007+.075*Math.sqrt(Math.max(0,1-(x/.154)**2-(y/.185)**2));
   lash.pivot.position.set(x,y,depth);
   lash.pivot.rotation.x=closure*1.05;
   lash.pivot.rotation.z=-lash.fan*.16;
  }
 }

 focus.copy(basePose).addScaledVector(leanDirection,leanAmount);focus.y+=1.35;const offset=cameraOffset(yaw,pitch);const obstruction=solidHit(focus,offset,blocks,distance,.18),targetDistance=obstruction?Math.max(.7,obstruction.distance-.12):distance;boomDistance=cameraDistance(boomDistance,targetDistance,dt);const dist=boomDistance;camera.position.copy(focus).addScaledVector(offset,dist);camera.position.y=Math.max(terrainFloor(camera.position.x,camera.position.z,p.y)+.2,camera.position.y);camera.lookAt(camera.position.clone().addScaledVector(offset,-10));avatar.visible=dist>1.8;
 const text=p.ground?'En tierra':'En el aire';if(text!==statusText){status.textContent=text;statusText=text;}
 scene.updateMatrixWorld(true);for(const e of eyes)e.eyeInverse.value.copy(e.eye.matrixWorld).invert();

 if(transferTime>0&&!menu.open&&!inventory.open&&!building.open){transferTime=Math.max(0,transferTime-dt);if(!transferSwapped&&transferTime<=.19){inventory.swapHands();transferSwapped=true;}}
 const paused=menu.open||inventory.open||building.open||chat.open||supply.open||!!document.querySelector('#arena-lobby[open]')||vitals.health<=0,swordHand=inventory.handOf('sword'),gunHand=firearmHand(),heldTool=inventory.heldTool(triggerRight?1:0);
 const aimActive=utilities.aiming||mouseMode||((gunHand>=0||swordHand>=0)&&(triggerLeft||triggerRight));
 camera.updateMatrixWorld(true);
 const scoped=!paused&&gun.kind==='sniper'&&gunHand>=0&&triggerRight;gun.stats.scoped=scoped;scope.hidden=!scoped;scope.style.filter=scoped?`blur(${Math.min(1.6,Math.hypot(p.vx,p.vz)*.22)}px)`:"";camera.fov=T.MathUtils.damp(camera.fov,scoped?18:progression.fov,14,dt);camera.updateProjectionMatrix();camera.updateMatrixWorld(true);const cx=innerWidth*.5,cy=innerHeight*(scoped?.5:.42);
 aimRay.setFromCamera(new T.Vector2(0,scoped?0:MATCH_SIGHT_Y),camera);aimRay.far=600;
 // Use the same collision surfaces as shots; avoid raycasting every visual triangle.
 const aimHit=solidHit(aimRay.ray.origin,aimRay.ray.direction,blocks,600);
 const aimedPlayer=combatTargets.hit(aimRay.ray.origin,aimRay.ray.direction,aimHit?aimHit.distance:600);
 const cameraTarget=aimedPlayer?.point||aimHit?.point||aimRay.ray.at(600,new T.Vector3());
 const aimOrigin=avatar.position.clone().add(new T.Vector3(0,.82,0)),desired=cameraTarget.clone().sub(aimOrigin).normalize();
 const targetYaw=Math.atan2(desired.x,desired.z)-Math.PI,targetPitch=-Math.asin(desired.y);
 const aimDirection=safeAimDirection(heading,targetYaw,targetPitch,aimActive);
 aimTarget.copy(aimOrigin).addScaledVector(aimDirection,Math.max(3,cameraTarget.distanceTo(aimOrigin)));
 const swordAiming=!building.placing&&swordHand>=0&&(swordHand===0?triggerLeft:triggerRight)&&!paused;
 handAnchors.forEach((a,i)=>a.position.set((i===0?1:-1)*(gun.twoHanded&&i===gunHand?.58:.86),(i===swordHand&&swordAiming||i===gunHand)?.49:.40,gun.twoHanded&&i===gunHand?.62:(i===swordHand&&swordAiming||i===gunHand)?.43:.12));const transferBlend=transferTime>0?Math.sin(Math.PI*(1-transferTime/.38)):0;for(const a of handAnchors){a.position.x*=1-transferBlend*.8;a.position.y-=transferBlend*.08;a.position.z+=transferBlend*.15;}body.updateMatrixWorld(true);
 const normalReload=gunHand>=0&&gun.stats.reload>0&&gun.stats.style==='normal'&&swordHand>=0;
 sword.temporaryStow(normalReload);
 sword.update(dt,p,handAnchors[swordHand>=0?swordHand:1],paused,swordAiming?aimTarget:null);
 for(const weapon of inventory.weapons){if(weapon.kind==='sword'){if(weapon!==sword)weapon.update(dt,p,handAnchors[inventory.itemHand(weapon)>=0?inventory.itemHand(weapon):0],paused,null);continue;}const wh=inventory.itemHand(weapon);weapon.stats.scoped=weapon===gun&&scoped;weapon.update(dt,{p,anchor:handAnchors[wh>=0?wh:0].getWorldPosition(new T.Vector3()),target:aimTarget,paused,npc:combatTargets,items:[...inventory.weapons,...inventory.extraItems],trigger:!paused&&transferTime===0&&!building.placing&&wh>=0&&actionHeld(weapon.twoHanded,wh,triggerLeft,triggerRight),both:inventory.both,colliders:obstacleMeshes,onRecoil:(vertical,horizontal)=>{pitch=T.MathUtils.clamp(pitch-vertical,-1.48,1.48);yaw+=horizontal;}});}
 if(!paused){const worldWeapons=inventory.weapons;for(let i=0;i<worldWeapons.length;i++)for(const other of worldWeapons.slice(i+1))if(worldWeapons[i].body.a.distanceTo(other.body.a)<5)collideItems(worldWeapons[i],other);}

 firePulse=false;
 if(!paused){punchCooldown=Math.max(0,punchCooldown-dt);swordCooldown=Math.max(0,swordCooldown-dt);if(gunHand<0&&swordHand<0&&!heldTool&&!inventory.hands().some(Boolean)&&!building.placing&&triggerLeft&&punchCooldown===0){punches[nextPunch].timer=.52;punches[nextPunch].hit=false;nextPunch=1-nextPunch;punchCooldown=.72;}}
 swordStructureCooldown=Math.max(0,swordStructureCooldown-dt);if(swordAiming&&!paused&&swordStructureCooldown===0){const hit=solidHit(avatar.position.clone().add(new T.Vector3(0,.6,0)),aimDirection,blocks,3.1);const origin=avatar.position.clone().add(new T.Vector3(0,.6,0));const enemy=[online.hit(origin,aimDirection,hit?hit.distance:3.1,.15),farm?.hit(origin,aimDirection,hit?hit.distance:3.1,.15)].filter(Boolean).sort((a,b)=>a.distance-b.distance)[0];if(enemy){enemy.apply(25,'sword');swordStructureCooldown=.85;}else if(hit?.block?.damage){hit.block.damage(25);swordStructureCooldown=.85;}}
 if(!swordAiming||!sword.body.npcContact)swordReady=true;if(!paused&&swordAiming&&sword.body.npcContact&&swordReady&&swordCooldown===0){npc.damage(25);online.npcDamage(25);swordReady=false;swordCooldown=.85;}
 if(!paused){toolCooldown=Math.max(0,toolCooldown-dt);if(heldTool&&!building.placing&&triggerLeft&&toolCooldown===0&&heldTool.item.durability>0){toolCooldown=.85;toolSwing=.6;toolHit=false;}toolSwing=Math.max(0,toolSwing-dt);if(heldTool&&toolSwing>0&&!toolHit&&toolSwing<.36){const direction=mouseMode?aimDirection:new T.Vector3(Math.sin(heading),0,Math.cos(heading)),origin=new T.Vector3(p.x,p.y+.7,p.z),wall=solidHit(origin,direction,blocks,2.4),target=combatTargets.hit(origin,direction,wall?wall.distance:2.4,.15);if(target){target.apply(heldTool.item.recipe.tool==='pick'?5:10);heldTool.item.use();inventory.refresh();}else if(wall?.block?.damage){wall.block.damage(heldTool.item.recipe.tool==='pick'?5:10);heldTool.item.use();}else if(wall?.block?.resource){const resource=wall.block,amount=harvest(heldTool.item.recipe,resource.resourceType);if(amount){materials[resource.resourceType]+=amount;heldTool.item.use();resource.node.userData.hitTime=.2;inventory.refresh();}}toolHit=true;}}
 for(const extra of inventory.extraItems){const active=heldTool?.item===extra;const extraHand=inventory.itemHand(extra);const anchor=handAnchors[extraHand>=0?extraHand:0].getWorldPosition(new T.Vector3());if(extraHand>=0&&extra.recipe.tool){anchor.set(avatar.position.x+Math.sin(heading)*.65,avatar.position.y+.62-transferBlend*.08,avatar.position.z+Math.cos(heading)*(.65+transferBlend*.15));}extra.packBlend=T.MathUtils.damp(extra.packBlend||0,extra.packing>0?1:0,12,dt);if(extraHand>=0&&extra.recipe.magazine){const centered=body.localToWorld(new T.Vector3((extraHand===0?1:-1)*.16,.12,.82));anchor.lerp(centered,extra.packBlend);}if(extraHand>=0){const use=farm?.handUse(extraHand);if(use){const target=body.localToWorld(new T.Vector3((extraHand===0?1:-1)*.2,use.eating?.58:.15,use.eating?.55:.7));anchor.lerp(target,use.blend);}}const throwPoint=utilities.handPoint(extraHand,heading);if(throwPoint)anchor.copy(throwPoint);extra.update(dt,p,anchor,heading,active&&toolSwing>0?1-toolSwing/.6:0,paused);}
 if(!paused){const extras=inventory.extraItems.filter(i=>i.state==='world');for(let i=0;i<extras.length;i++){for(const other of [...inventory.weapons,...extras.slice(i+1)])if(extras[i].body.a.distanceTo(other.body.a)<5)collideItems(extras[i],other);}}
 for(let i=0;i<2;i++){
  let point=null;const packingMag=inventory.extraItems.find(item=>(item.packBlend||0)>.05&&inventory.itemHand(item)>=0&&inventory.itemHand(item)!==i);if(packingMag&&(!inventory.hands()[i]||inventory.extraItems.some(item=>inventory.itemHand(item)===i&&item.packingHidden)))point=packingMag.loadingPoint();const heldExtra=inventory.extraItems.find(item=>inventory.itemHand(item)===i);if(heldExtra&&!heldExtra.packingHidden)point=heldExtra.gripPoint();if(i===swordHand&&!normalReload)point=sword.gripPoint(0);if(inventory.weaponAt(i)?.stats)point=inventory.weaponAt(i).gripPoint();if(heldTool)point=heldTool.hand===i?heldTool.item.gripPoint():heldTool.item.supportPoint();if(normalReload&&i===swordHand||gun.twoHanded&&gunHand>=0&&i!==gunHand)point=gun.supportPoint();
  if(!paused&&gunHand<0&&swordHand<0){const punch=punches[i];if(punch.timer>0){punch.timer=Math.max(0,punch.timer-dt);const direction=mouseMode?aimDirection.clone():new T.Vector3(Math.sin(heading),0,Math.cos(heading)),origin=new T.Vector3(p.x,p.y+.65,p.z);if(!punch.hit&&punch.timer<.35){const wall=solidHit(origin,direction,blocks,1.85),hit=combatTargets.hit(origin,direction,wall?wall.distance:1.85,.14);if(hit)hit.apply(8);else if(wall?.block?.damage)wall.block.damage(8);else if(wall?.block?.resource){const resource=wall.block;materials[resource.resourceType]+=harvest(null,resource.resourceType);resource.node.userData.hitTime=.2;document.getElementById('wood-count').textContent=materials.wood;document.getElementById('stone-count').textContent=materials.stone;}punch.hit=true;}const phase=(.52-punch.timer)/.52,reach=Math.sin(Math.PI*phase)*.95;point=body.localToWorld(new T.Vector3(arms[i].side*.48,.57,.24)).addScaledVector(direction,reach);}}
  else if(paused||gunHand>=0||swordHand>=0||heldTool){punches[i].timer=0;}
  
  const throwHand=utilities.handPoint(i,heading);if(throwHand)point=throwHand;
  if(point){const a=arms[i],local=body.worldToLocal(point);const packingArm=!!(packingMag||(heldExtra?.packBlend||0)>.05);const supporting=packingArm||(gun.twoHanded&&gunHand>=0&&i!==gunHand)||(heldTool&&i!==heldTool.hand)||(normalReload&&i===swordHand);const shoulder=a.anchor;const delta=local.clone().sub(shoulder);if(delta.length()>1.03)delta.setLength(1.03);local.copy(shoulder).add(delta);const length=delta.length();a.forearm.visible=false;a.hand.position.copy(local);a.mesh.position.copy(shoulder).addScaledVector(delta,.5);a.mesh.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),delta.normalize());a.mesh.scale.set(.115,length/2+.025,.115);}
 }
 hair.update({...p,heading,hair:preferences.hair,hairColor:preferences.hairColor},dt);ui.update(dt);sounds.update(dt);voice.update();supply.update();chat.update();sight.update({dt,visible:!paused&&!scoped&&gun.kind!=='sniper'&&(gunHand>=0||swordAiming),x:cx,y:cy,spread:gunHand>=0?Math.min(2,gun.stats.spread+(p.ground?0:1)):0});
 ammoHUD.querySelector('small').textContent=gun.kind==='sniper'?'SNIPER':gun.kind==='rifle'?'AK · DOS MANOS':'SUBFUSIL · DOS MANOS';ammoHUD.hidden=gunHand<0;document.getElementById('ammo-count').textContent=gun.stats.ammo+' / '+gun.stats.capacity;document.getElementById('ammo-reserve').textContent=globalThis.pomponArena?'Reserva infinita':'Cargadores listos: '+inventory.loadedCount(gun.kind);document.getElementById('reload-status').textContent=gun.stats.reload>0?(gun.stats.style==='flip'?'Recarga con giro':'Cambiando cargador')+' · '+gun.stats.reload.toFixed(1)+' s':'R · Recargar'+(gun.kind==='sniper'?' · Derecho: mira':'');document.getElementById('reload-progress').value=gun.stats.reload>0?1-gun.stats.reload/gun.stats.reloadDuration:0;
 const ammoScale=(ammoStyle==='hologram'?display.settings.holoSize:display.settings.panelSize)/100;ammoHUD.style.scale=ammoScale;ammoHUD.style.transformOrigin=ammoStyle==='hologram'?'top left':'bottom right';
 const holographic=ammoStyle==='hologram';ammoHUD.classList.toggle('holographic',holographic);
 if(holographic&&gunHand>=0){const hp=gun.ammoPoint().project(camera);const center=avatar.position.clone().add(new T.Vector3(0,.55,0)).project(camera),weaponX=(hp.x+1)*innerWidth/2,bodyX=(center.x+1)*innerWidth/2,width=185*ammoScale;const outward=gunHand===0?-1:1;const edge=avatar.position.clone().add(new T.Vector3(Math.cos(yaw)*outward*.72,.55,-Math.sin(yaw)*outward*.72)).project(camera),edgeX=(edge.x+1)*innerWidth/2;const hudX=outward>0?Math.max(weaponX,edgeX)+24:Math.min(weaponX,edgeX)-width-24;const desiredX=T.MathUtils.clamp(hudX,12,innerWidth-width-12),desiredY=T.MathUtils.clamp((1-hp.y)*innerHeight/2-55,12,innerHeight-155*ammoScale);holoX=holoX===null?desiredX:T.MathUtils.damp(holoX,desiredX,12,dt);holoY=holoY===null?desiredY:T.MathUtils.damp(holoY,desiredY,12,dt);ammoHUD.style.left=holoX+'px';ammoHUD.style.top=holoY+'px';ammoHUD.hidden=paused||hp.z>1||hp.z< -1;}else{ammoHUD.style.left='';ammoHUD.style.top='';}
 backpackVisual.visible=inventory.backpack;farm?.update(dt,paused);water.update(dt);chests.update(dt);utilities.update(dt);terrainRender.update();building.update(dt,paused);document.getElementById('wood-count').textContent=materials.wood;document.getElementById('stone-count').textContent=materials.stone;document.getElementById('iron-count').textContent=materials.iron||0;
 npc.update(dt,camera,paused);
 document.getElementById('health-value').textContent=Math.ceil(vitals.health)+'%';document.getElementById('health-meter').value=vitals.health;
 document.getElementById('stamina-value').textContent=Math.ceil(vitals.stamina)+'%';document.getElementById('stamina-meter').value=vitals.stamina;
 inventory.update();online.update(dt);
 for(const node of resourceNodes){node.visible=node.position.distanceTo(camera.position)<display.settings.viewDistance;if(!paused)node.userData.hitTime=Math.max(0,node.userData.hitTime-dt);node.rotation.z=Math.sin(node.userData.hitTime*45)*node.userData.hitTime*.17;}
 sun.position.set(p.x-12,25,p.z+12);sun.target.position.set(p.x,0,p.z);sun.target.updateMatrixWorld();
 progression.update();arena.update();sessionRoster.update();frontEnd.update(dt);spectator.update(dt);online.projectLabels();if(now-shadowAt>=(display.settings.quality==='high'?16:33)){renderer.shadowMap.needsUpdate=true;shadowAt=now;}renderer.render(scene,camera);requestAnimationFrame(frame);
}
addEventListener('resize',()=>{camera.aspect=renderAspect();camera.updateProjectionMatrix();renderer.setSize(...renderSize(),false);Object.assign(renderer.domElement.style,{width:"100%",height:"100%"});});requestAnimationFrame(frame);


addEventListener('pompon-desktop-save',async()=>{try{await frontEnd.save();globalThis.chrome?.webview?.postMessage('pompon-saved');}catch(e){globalThis.chrome?.webview?.postMessage('pompon-save-error:'+e.message);}});



