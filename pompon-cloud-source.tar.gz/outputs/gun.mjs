import {weaponRange} from './combat-rules.mjs';
import {sound} from './sound.mjs';
import {collisionParts} from './structure-collision.mjs';
import {solidHit,itemHit,impulse} from './combat-physics.mjs';
import * as T from './vendor/three.module.js';
import {createDebris} from './debris.mjs';
import {weaponIcon} from './weapon-icon.mjs';
import {makeSwordBody,stepSword} from './sword-physics.mjs';
import {createGunState,fireGun,reloadGun,tickGun} from './gun-state.mjs';
export function createGun(scene,blocks,carrier,rifle=false,options={}){
 const sniper=rifle==='sniper',kind=sniper?'sniper':rifle?'rifle':'gun',damage=sniper?100:rifle?17:12;
 const root=new T.Group(),rig=new T.Group();root.add(rig);scene.add(root);
 const steel=new T.MeshStandardMaterial({color:0x35424e,metalness:.65,roughness:.35}),rubber=new T.MeshStandardMaterial({color:0x1b2429,roughness:.9}),accent=new T.MeshStandardMaterial({color:0xc69e55,metalness:.6,roughness:.4});
 function box(w,h,d,x,y,z,material=steel){const m=new T.Mesh(new T.BoxGeometry(w,h,d),material);m.position.set(x,y,z);m.castShadow=true;rig.add(m);return m;}
 box(.19,.22,.64,0,.16,.22);box(.14,.32,.15,0,-.03,0,rubber).rotation.x=-.2;
 const mag=box(.12,.39,.17,0,-.14,.26,rubber);mag.rotation.x=.12;
 box(.16,.13,.25,0,.12,-.18,rubber);box(.22,.25,.07,0,.07,-.34,rubber);
 const barrel=new T.Mesh(new T.CylinderGeometry(.048,.048,.43,12),steel);barrel.rotation.x=Math.PI/2;barrel.position.set(0,.17,.69);rig.add(barrel);
 box(.13,.055,.44,0,.31,.18,rubber);box(.06,.09,.055,0,.36,.38,accent);box(.06,.075,.055,0,.35,-.04,accent);
 for(let i=0;i<5;i++)box(.205,.025,.035,0,.16,.2+i*.055,rubber);
 const muzzle=new T.Object3D();muzzle.position.set(0,.17,.92);rig.add(muzzle);
 const flash=new T.Mesh(new T.ConeGeometry(.10,.33,6),new T.MeshBasicMaterial({color:0xffdc85,transparent:true,opacity:.9}));flash.rotation.x=Math.PI/2;flash.position.set(0,.17,1.03);flash.visible=false;rig.add(flash);
 if(rifle){for(const child of [...rig.children])if(child!==mag&&child!==muzzle&&child!==flash)rig.remove(child);
 const wood=new T.MeshStandardMaterial({color:0x9f542b,roughness:.7});
 box(.20,.24,.66,0,.16,.25);box(.15,.30,.16,0,-.035,0,rubber).rotation.x=-.18;
 box(.21,.22,.48,0,.13,-.43,wood);box(.17,.19,.24,0,.13,-.13);box(.24,.32,.09,0,.10,-.70,rubber);
 box(.23,.19,.43,0,.15,.77,wood);box(.12,.07,.86,0,.32,.52);
 const longBarrel=new T.Mesh(new T.CylinderGeometry(.041,.041,.64,12),steel);longBarrel.rotation.x=Math.PI/2;longBarrel.position.set(0,.20,1.19);rig.add(longBarrel);
 box(.08,.19,.07,0,.28,1.4);box(.10,.08,.10,0,.34,.22);mag.scale.set(1.15,1.28,1.15);mag.rotation.x=-.24;
 const curve=new T.Mesh(new T.BoxGeometry(.12,.16,.18),rubber);curve.position.set(0,-.24,.035);curve.rotation.x=-.28;mag.add(curve);
 muzzle.position.set(0,.20,1.55);flash.position.set(0,.20,1.68);
 }
 if(sniper){const scope=new T.Mesh(new T.CylinderGeometry(.095,.095,.65,16),rubber);scope.rotation.x=Math.PI/2;scope.position.set(0,.49,.25);rig.add(scope);box(.12,.17,.1,0,.36,.1);box(.12,.17,.1,0,.36,.4);box(.18,.15,.5,0,.15,.78,rubber);muzzle.position.z=1.9;flash.position.z=2.02;const tube=new T.Mesh(new T.CylinderGeometry(.045,.045,.75,12),steel);tube.rotation.x=Math.PI/2;tube.position.set(0,.2,1.53);rig.add(tube);mag.scale.y=.55;}
 mag.name='magazine';flash.name='muzzle-flash';const iconURL=options.icon===false?'':weaponIcon(root),mini=root.clone(true);mini.visible=false;mini.scale.setScalar(.48);carrier.add(mini);
 const debris=createDebris(scene,blocks);let magEjected=false;
 let wallLift=0;let state='world',slot=1,body=makeSwordBody(),acc=0,flashTime=0;body.length=rifle?1.5:.8;body.a.set(rifle?1.3:-1.4,.14,rifle?5.8:3.6);body.b.copy(body.a).add(new T.Vector3(0,0,body.length));body.oldA.copy(body.a);body.oldB.copy(body.b);
 const stats=createGunState(),up=new T.Vector3(0,1,0),ray=new T.Raycaster();
 if(sniper){stats.capacity=5;stats.fireInterval=1.15;}const trails=[];for(let i=0;i<24;i++){const line=new T.Mesh(new T.CylinderGeometry(.026,.026,1,6),new T.MeshBasicMaterial({color:0xffcd42,transparent:true,opacity:1,depthWrite:false}));line.visible=false;line.frustumCulled=false;scene.add(line);trails.push({line,life:0,start:new T.Vector3(),end:new T.Vector3(),age:0,duration:.22});}let trailIndex=0;
 function mount(i){slot=i;mini.position.set((i%2===0?1:-1)*.18,.77,-.62-(i>1?.12:0));mini.rotation.set(Math.PI/2,0,i%2===0?.28:-.28);mini.scale.setScalar(.32);}
 let externallyHidden=false;function visibility(){root.visible=!externallyHidden&&state!=='stored';mini.visible=!externallyHidden&&state==='stored'&&slot>=0&&slot<5;}
 return {setHidden(value){externallyHidden=value;visibility();},clearEffects(){debris.clear();for(const t of trails){t.life=0;t.line.visible=false;}flash.visible=false;},stowedPose(){return mini.visible?{kind,position:mini.position.toArray(),quaternion:mini.quaternion.toArray(),scale:mini.scale.toArray()}:null;},pose(){root.updateMatrixWorld(true);return {position:rig.getWorldPosition(new T.Vector3()).toArray(),quaternion:rig.getWorldQuaternion(new T.Quaternion()).toArray(),magY:mag.position.y,magVisible:mag.visible,flash:flash.visible};},kind,twoHanded:true,stats,damage,iconURL,ammoPoint(){root.updateMatrixWorld(true);return rig.localToWorld(new T.Vector3(.28,.55,.3));},get body(){return body;},visualClone(){const model=rig.clone(true);model.position.set(0,0,0);model.rotation.set(0,0,0);model.visible=true;return model;},get state(){return state;},mount,
 near(p){return state==='world'&&body.a.distanceTo(new T.Vector3(p.x,p.y+.5,p.z))<2.25;},pickup(i=0){state='stored';mount(i);visibility();},store(i=slot){this.clearEffects();state='stored';mount(i);stats.reload=0;mag.visible=true;mag.position.y=-.14;visibility();},equip(){state='equipped';visibility();},
 drop(p,heading){state='world';stats.reload=0;mag.visible=true;mag.position.y=-.14;body.a.set(p.x+Math.sin(heading),p.y+.8,p.z+Math.cos(heading));body.b.copy(body.a).add(new T.Vector3(body.length,.1,0));body.oldA.copy(body.a);body.oldB.copy(body.b);visibility();},
 reload(both,feed){if(state!=='equipped'||stats.reload>0||stats.ammo===stats.capacity)return false;const rounds=feed?feed(kind):0;if(!rounds)return false;stats.reserve=Math.min(stats.capacity,rounds);stats.ammo=0;const ok=reloadGun(stats,true);if(ok){magEjected=false;stats.reloadStage=0;sound('reload');}return ok;},
 gripPoint(){root.updateMatrixWorld(true);return rig.localToWorld(new T.Vector3(0,-.02,0));},supportPoint(){root.updateMatrixWorld(true);const rest=new T.Vector3(0,.025,.48);if(stats.reload>0){const t=1-stats.reload/stats.reloadDuration;const grasp=new T.Vector3(0,-.35,.26);if(t<.15)rest.lerp(grasp,t/.15);else if(t<.72){rest.copy(grasp);rest.y-=Math.sin((t-.15)/.57*Math.PI)*.48;}else if(t<.88)rest.set(.16,.30,.3);else rest.lerp(new T.Vector3(.16,.30,.3),(1-t)/.12);}return rig.localToWorld(rest);},
 update(dt,{p,anchor,target,paused,trigger,both,colliders,onRecoil,items=[],npc}){
  visibility();if(paused||state==='stored')return;debris.update(dt);tickGun(stats,dt);flashTime=Math.max(0,flashTime-dt);flash.visible=flashTime>0;
  if(state==='world'){acc+=dt;while(acc>=1/120){stepSword(body,1/120,blocks,null,null,p);acc-=1/120;}root.position.copy(body.a);root.quaternion.setFromUnitVectors(new T.Vector3(0,0,1),body.b.clone().sub(body.a).normalize());rig.rotation.set(0,0,Math.PI/2);rig.position.set(0,0,0);}
  if(state==='equipped'){
   root.position.copy(anchor);root.lookAt(target);rig.rotation.set(0,0,0);rig.position.set(0,0,-stats.recoil*.08);
   // Sweep the complete receiver/barrel from the hand, then tuck upward at walls.
   const forward=target.clone().sub(anchor).normalize(),nearWall=solidHit(anchor.clone().add(new T.Vector3(0,.20,0)),forward,blocks,rifle?1.55:.9,.035);
   wallLift+=(Number(!!nearWall)-wallLift)*(1-Math.exp(-(nearWall?35:20)*dt));
   if(wallLift>.001){const raised=forward.clone().lerp(new T.Vector3(0,1,0),.96*wallLift).normalize();root.position.y+=.18*wallLift;root.lookAt(root.position.clone().add(raised));}
   // Keep the grip within a short arm's reach; never teleport it above a wall.
   if(nearWall){root.position.copy(anchor).addScaledVector(forward,-.10*wallLift);root.position.y+=.08*wallLift;root.lookAt(root.position.clone().add(forward.clone().lerp(new T.Vector3(0,1,0),.98*wallLift).normalize()));}


   if(stats.reload>0){const t=1-stats.reload/stats.reloadDuration;const stage=t>.8?2:t>.45?1:0;if(stage>stats.reloadStage){stats.reloadStage=stage;sound('reload',stage===2?.7:1);}
    if(stats.style==='flip'){rig.rotation.z=Math.sin(Math.PI*t)*.75;rig.position.y=Math.sin(Math.PI*t)*.13;rig.rotation.x=-Math.sin(Math.PI*t)*.35;}else{rig.rotation.x=-Math.sin(Math.PI*t)*.30;rig.rotation.z=Math.sin(Math.PI*t)*.22;}
    mag.visible=t<.18||t>.77;mag.position.y=t>.77?-.14-(1-t)*1.0:-.14;
    if(t>=.18&&!magEjected){root.updateMatrixWorld(true);debris.emit('magazine',mag.getWorldPosition(new T.Vector3()),new T.Vector3(.4,-1.7,.3));magEjected=true;}
   }else{mag.visible=true;mag.position.y=-.14;}
   rig.rotation.x+=stats.recoil*.08;root.updateMatrixWorld(true);
   body.oldA.copy(body.a);body.oldB.copy(body.b);body.a.copy(root.position);muzzle.getWorldPosition(body.b);
   if(trigger&&fireGun(stats)){sound('shot');
    const origin=muzzle.getWorldPosition(new T.Vector3()),direction=nearWall?new T.Vector3(0,0,1).transformDirection(rig.matrixWorld):target.clone().sub(origin).normalize(),spread=(sniper?(stats.scoped?(.0005+Math.min(1,Math.hypot(p.vx,p.vz)/3)*.065):.24):(.004+stats.spread*.055))+(p.ground?0:.18);direction.add(new T.Vector3((Math.random()-.5)*spread,(Math.random()-.5)*spread,(Math.random()-.5)*spread)).normalize();
    const eject=rig.localToWorld(new T.Vector3(.13,.20,.18)),sideVector=new T.Vector3(1,0,0).applyQuaternion(root.quaternion);debris.emit('shell',eject,sideVector.multiplyScalar(2.0).add(new T.Vector3(0,1.6,0)));
    const muzzlePath=origin.clone().sub(root.position),guard=solidHit(root.position,muzzlePath.clone().normalize(),blocks,muzzlePath.length());
    const wall=guard?{distance:0,point:guard.point,block:guard.block}:solidHit(origin,direction,blocks,weaponRange(kind)),object=guard?null:itemHit(origin,direction,items,wall?wall.distance:(weaponRange(kind)));
    const targetNPC=guard?null:npc?.hit(origin,direction,object?object.distance:wall?wall.distance:(weaponRange(kind)));if(targetNPC)targetNPC.apply(damage,kind);
    if(wall&&!object&&!targetNPC)wall.block?.damage?.(damage);
    if(object&&!targetNPC)impulse(object.item.body,direction,object.item===items[0]?6:9);
    const end=targetNPC?targetNPC.point:object?object.point:wall?wall.point:origin.clone().addScaledVector(direction,weaponRange(kind)),tr=trails[trailIndex++%trails.length];tr.start.copy(origin);tr.end.copy(end);tr.age=0;tr.duration=Math.max(.08,Math.min(.24,origin.distanceTo(end)/90));tr.life=tr.duration;tr.line.visible=false;flashTime=.045;flash.visible=true;onRecoil(.008+stats.spread*.009,(Math.random()-.5)*.007);
   }
  }
  for(const t of trails){t.life=Math.max(0,t.life-dt);t.age+=dt;t.line.visible=t.life>0;if(!t.line.visible)continue;const delta=t.end.clone().sub(t.start),total=delta.length();if(total<.01){t.line.visible=false;continue;}delta.divideScalar(total);const head=total*Math.min(1,t.age/t.duration),tail=Math.max(0,head-1.7),length=Math.max(.05,head-tail);t.line.position.copy(t.start).addScaledVector(delta,(head+tail)/2);t.line.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),delta);t.line.scale.set(1,length,1);t.line.material.opacity=1;}
 }
 };
}
