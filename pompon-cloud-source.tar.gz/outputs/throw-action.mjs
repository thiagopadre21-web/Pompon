// The fuse starts after release, never while aiming.
export function createThrowAction(){let state=null;return {
 begin(hand,id,kind){if(state)return false;state={hand,id,kind,phase:'aim',time:0,released:false};return true;},
 release(direction){if(state?.phase!=='aim')return false;state.phase='throw';state.time=0;state.direction={x:direction.x,y:direction.y,z:direction.z};return true;},
 cancel(){state=null;},get state(){return state;},
 update(dt,valid,launch){if(!state)return;if(!valid(state)){state=null;return;}state.time+=Math.max(0,Math.min(.05,dt));if(state.phase==='throw'&&!state.released&&state.time>=.18){state.released=true;launch({...state});}if(state?.phase==='throw'&&state.time>=.42)state=null;},
 pose(hand){if(!state||state.hand!==hand)return null;const t=state.phase==='aim'?0:Math.min(1,state.time/.24),blend=state.phase==='aim'?Math.min(1,state.time/.18):1;return {back:(-.62+1.62*t)*blend,height:1.25+.22*Math.sin(t*Math.PI),blend};}
};}
